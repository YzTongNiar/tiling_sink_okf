"""npu_fused_infer_attention_score_v2_sink 统一入口（plans/04 §4）。

形态（plans/03）:
  eager 两段式:
    meta = _metadata(...)   ← AICPU 前置算子（device 读 seq len, SplitCore 分核, 产出 uint32[1024]）
    out, lse = 主算子(..., meta_data=meta)   ← AICore kernel 从 GM metadata 驱动调度
  aclgraph（R2）:
    entry_graph() 按 omni-ops 文档双流写法捕获（metadata → aicpu_stream, 主算子 → aicore_stream
    + event 依赖）；replay 前仅 qlen.copy_()/kvlen.copy_() 原地更新。

约定:
  - actual_seq_qlen/kvlen 为 device INT64 [B]（R3: 全程零 D2H/H2D）；qlen=累积和, kvlen=每 req 真实长度
  - 主算子必须携带 meta_data（裸调主算子会 aclnn 失败, plans/03 §6.9 实证）
  - out [N1,T,512]（TND_NTD NTD 布局）; lse [T,N1,1] FP32
  - W1 GQA 开放（plans/08 §3.2）: query_rope=None → rope_head_dim=0 → AICPU GQA 分支;
    num_key_value_heads>1 且 head_dim∈{64,128,192} 的 KV 池形态受支持;
    input_layout_kv 从写死 "PA" 参数化（GQA 接入常用 BnBsH 族布局）
"""
import torch
import torch_npu  # noqa: F401
try:
    import fia_v2_sink_ops  # noqa: F401  注册 torch.ops.custom.* schema
except ImportError as e:
    raise ImportError("fia_v2_sink_ops wheel 未安装 (cd torch_ops && bash build_and_install.sh)") from e

DEFAULT_SCALE = 0.0721687836487032  # 1/sqrt(192)


def _core_nums(device):
    p = torch.npu.get_device_properties(device if device is not None else 0)
    return p.cube_core_num, p.vector_core_num


def _rope_head_dim(query_rope):
    """W1（plans/08 §3.2）: query_rope=None → rope_head_dim=0
    → AICPU CheckIsMla()=false → GQA 分支（CalcInnerSizeGqa/CreateSplitInputGqa）。"""
    return int(query_rope.shape[-1]) if query_rope is not None else 0


def _infer_num_key_value_heads(key, num_key_value_heads):
    """W1: num_key_value_heads 默认值放开——None 时从 KV 池形状派生。

    派生规则: PA 池 [block_num, N2, block_size, D]（4 维）→ shape[1]。
    MLA 路径现有调用方显式传 kvh=1，派生值同为 1，行为不变；
    其余 KV 形态（如 BBH 3 维池）无法唯一推导，要求显式传入。"""
    if num_key_value_heads is not None:
        return int(num_key_value_heads)
    if key.dim() == 4:
        return int(key.shape[1])
    raise ValueError(
        "num_key_value_heads 必须显式传入: KV 张量非 4 维 PA 池时无法从形状自动推导 "
        f"(key.dim()={key.dim()}, shape={tuple(key.shape)})")


def metadata(num_query_heads, num_key_value_heads, head_dim_qk, head_dim_v,
             actual_seq_qlen, actual_seq_kvlen, *, batch_size=0, sparse_mode=0,
             pre_tokens=2147483647, next_tokens=2147483647, input_layout="TND_NTD",
             input_layout_kv="PA", sink_num=0, k_sink_num=0, rope_head_dim=64,
             block_size=128, aic_core_num=None, aiv_core_num=None, batch_invariant=False):
    """AICPU 前置分核算子单独调用（冒烟/图模式复用）。"""
    if aic_core_num is None or aiv_core_num is None:
        aic, aiv = _core_nums(actual_seq_qlen.device.index if actual_seq_qlen is not None else None)
        aic_core_num = aic_core_num or aic
        aiv_core_num = aiv_core_num or aiv
    return torch.ops.custom._npu_fused_infer_attention_score_v2_sink_metadata(
        num_query_heads, num_key_value_heads, head_dim_qk, head_dim_v,
        actual_seq_lengths=actual_seq_qlen, actual_seq_lengths_kv=actual_seq_kvlen,
        batch_size=batch_size, sparse_mode=sparse_mode,
        pre_tokens=pre_tokens, next_tokens=next_tokens,
        input_layout=input_layout, input_layout_kv=input_layout_kv,
        sink_num=sink_num, k_sink_num=k_sink_num, rope_head_dim=rope_head_dim,
        block_size=block_size, aic_core_num=aic_core_num, aiv_core_num=aiv_core_num,
        batch_invariant=batch_invariant)


def entry(query, key, value, *, query_rope=None, key_rope=None, atten_mask=None,
          block_table=None, actual_seq_qlen=None, actual_seq_kvlen=None,
          num_query_heads=None, num_key_value_heads=None, input_layout="TND_NTD",
          input_layout_kv="PA",
          sparse_mode=None, softmax_scale=DEFAULT_SCALE, block_size=128,
          pre_tokens=2147483647, next_tokens=2147483647,
          return_softmax_lse=True, meta_data=None):
    """eager 两段式调用: (可选外部 meta) → 主算子。返回 (out, lse)。

    W1 GQA 开放（plans/08 §3.2）:
      - query_rope/key_rope 可为 None: rope_head_dim 自动取 0 → AICPU 落 GQA 分支;
        MLA 用法不变（rope 必传时语义与原来完全一致）。
      - input_layout_kv 参数化（原写死 "PA"）: PA 池传 "PA"，KV 连续 TND 族按实际布局传。
      - num_key_value_heads 放开: None 时从 4 维 KV 池 [pool, N2, BS, D] 的 shape[1] 派生。
    """
    if sparse_mode is None:
        sparse_mode = 3 if (atten_mask is not None) else 0
    num_key_value_heads = _infer_num_key_value_heads(key, num_key_value_heads)
    if meta_data is None:
        meta_data = metadata(
            num_query_heads, num_key_value_heads, query.shape[-1], value.shape[-1],
            actual_seq_qlen, actual_seq_kvlen, sparse_mode=sparse_mode,
            pre_tokens=pre_tokens, next_tokens=next_tokens,
            input_layout=input_layout, input_layout_kv=input_layout_kv,
            rope_head_dim=_rope_head_dim(query_rope), block_size=block_size)
    out, lse = torch.ops.custom.npu_fused_infer_attention_score_v2_sink(
        query, key, value, query_rope=query_rope, key_rope=key_rope,
        atten_mask=atten_mask, actual_seq_qlen=actual_seq_qlen,
        actual_seq_kvlen=actual_seq_kvlen, block_table=block_table,
        meta_data=meta_data,
        num_query_heads=num_query_heads, num_key_value_heads=num_key_value_heads,
        input_layout=input_layout, sparse_mode=sparse_mode,
        softmax_scale=softmax_scale, block_size=block_size,
        pre_tokens=pre_tokens, next_tokens=next_tokens,
        return_softmax_lse=return_softmax_lse)
    return out, lse


class SinkGraph:
    """aclgraph 双流封装（R2, plans/03 §2.7 参考写法）。

    用法:
        g = SinkGraph()
        g.capture(query, key, value, ...)          # 捕获（含 metadata + 主算子两段）
        out, lse = g.replay()                      # 每步前 qlen.copy_(...) / kvlen.copy_(...) 原地更新
    """

    def __init__(self):
        self.graph = None
        self.static_out = None
        self.static_lse = None
        self._qlen = None
        self._kvlen = None
        self._meta = None
        self._meta_args = None

    def capture(self, query, key, value, *, query_rope=None, key_rope=None, atten_mask=None,
                block_table=None, actual_seq_qlen=None, actual_seq_kvlen=None,
                num_query_heads=None, num_key_value_heads=None, input_layout="TND_NTD",
                input_layout_kv="PA",
                sparse_mode=None, softmax_scale=DEFAULT_SCALE, block_size=128,
                pre_tokens=2147483647, next_tokens=2147483647,
                return_softmax_lse=True, warmup=2):
        """按 omni-ops 文档图模式写法捕获（metadata → aicpu_stream, 主算子 → aicore_stream + event 依赖）。

        actual_seq_qlen/kvlen 必须是捕获后由调用方原地更新（copy_）的持久 buffer。
        W1: GQA 形态（query_rope=None / kvh>1 / input_layout_kv 参数化）与 entry() 同步开放。
        """
        assert self.graph is None, "graph already captured"
        if sparse_mode is None:
            sparse_mode = 3 if (atten_mask is not None) else 0
        num_key_value_heads = _infer_num_key_value_heads(key, num_key_value_heads)
        rope_head_dim = _rope_head_dim(query_rope)
        self._qlen = actual_seq_qlen
        self._kvlen = actual_seq_kvlen

        # warmup（旁路 stream）: 建 tiling cache/workspace + 捕获组 workspace 定容（isMaxWorkspace 分支）
        s = torch.npu.Stream()
        s.wait_stream(torch.npu.current_stream())
        with torch.npu.stream(s):
            for _ in range(warmup):
                entry(query, key, value, query_rope=query_rope, key_rope=key_rope,
                      atten_mask=atten_mask, block_table=block_table,
                      actual_seq_qlen=self._qlen, actual_seq_kvlen=self._kvlen,
                      num_query_heads=num_query_heads, num_key_value_heads=num_key_value_heads,
                      input_layout=input_layout, input_layout_kv=input_layout_kv,
                      sparse_mode=sparse_mode,
                      softmax_scale=softmax_scale, block_size=block_size,
                      pre_tokens=pre_tokens, next_tokens=next_tokens,
                      return_softmax_lse=return_softmax_lse)
        torch.npu.current_stream().wait_stream(s)

        aicore_stream = torch.npu.current_stream()
        aicpu_stream = torch.npu.Stream()
        event = torch.npu.Event()
        g = torch.npu.NPUGraph()
        with torch.npu.graph(g):
            with torch.npu.stream(aicpu_stream):
                meta = metadata(
                    num_query_heads, num_key_value_heads, query.shape[-1], value.shape[-1],
                    self._qlen, self._kvlen, sparse_mode=sparse_mode,
                    pre_tokens=pre_tokens, next_tokens=next_tokens,
                    input_layout=input_layout, input_layout_kv=input_layout_kv,
                    rope_head_dim=rope_head_dim, block_size=block_size)
                self._meta = meta          # 静态 metadata buffer（graph 主算子读它的地址）
                self._meta_args = dict(
                    nhq=num_query_heads, nhkv=num_key_value_heads, dqk=query.shape[-1], dv=value.shape[-1],
                    sparse_mode=sparse_mode, pre_tokens=pre_tokens, next_tokens=next_tokens,
                    input_layout=input_layout, input_layout_kv=input_layout_kv,
                    rope_head_dim=rope_head_dim, block_size=block_size)
                event.record(aicpu_stream)  # 跨流依赖: 主算子等 metadata 完成
            with torch.npu.stream(aicore_stream):
                aicore_stream.wait_event(event)
                self.static_out, self.static_lse = torch.ops.custom.npu_fused_infer_attention_score_v2_sink(
                    query, key, value, query_rope=query_rope, key_rope=key_rope,
                    atten_mask=atten_mask, actual_seq_qlen=self._qlen,
                    actual_seq_kvlen=self._kvlen, block_table=block_table,
                    meta_data=meta,
                    num_query_heads=num_query_heads,
                    num_key_value_heads=num_key_value_heads,
                    input_layout=input_layout, sparse_mode=sparse_mode,
                    softmax_scale=softmax_scale, block_size=block_size,
                    pre_tokens=pre_tokens, next_tokens=next_tokens,
                    return_softmax_lse=return_softmax_lse)
        self.graph = g
        return self

    def replay(self):
        """混合重放: eager metadata（读当前 qlen/kvlen 值）→ copy 进静态 meta buffer → graph.replay()。

        平台实证（cann-9.1.0 + torch_npu 2.10, 本机 910_9362）: aclGraph 捕获含 DNN_VM_AICPU 自定义节点时,
        捕获成功且节点在图中, 但重放不重新执行 AICPU 任务（metadata 内容固化在捕获时刻）;
        主 AICore kernel 正常重放并读 live GM。故每步以 eager AICPU metadata 重算分核写入同一 buffer,
        主算子随图重放 —— R1（AICPU 分核每步执行）/R3（零 D2H）语义保持。
        """
        assert self.graph is not None
        a = self._meta_args
        fresh = metadata(a["nhq"], a["nhkv"], a["dqk"], a["dv"], self._qlen, self._kvlen,
                         sparse_mode=a["sparse_mode"], pre_tokens=a["pre_tokens"],
                         next_tokens=a["next_tokens"], input_layout=a["input_layout"],
                         input_layout_kv=a["input_layout_kv"], rope_head_dim=a["rope_head_dim"],
                         block_size=a["block_size"])
        self._meta.copy_(fresh)  # 同 stream D2D 4KB, 先于 graph 主算子
        self.graph.replay()
        return self.static_out, self.static_lse
