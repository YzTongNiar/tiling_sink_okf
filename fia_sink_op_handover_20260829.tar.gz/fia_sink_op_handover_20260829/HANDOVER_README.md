# FIA v2 Sink/Metadata 算子交接包（round_5 结档态，2026-08-29）

本包为 FIA v2 Sink 双算子（AICPU tiling 下沉变体，服务 vllm-ascend GLM-5.2 DSpark draft
与主模型 verify 潜在切换）的完整交接：源码 + 编译产物 + 门禁 + 证据 + 知识包。

## 0. 当前态一句话

round=2 交付（status=done）：D192(GQA) 104 tiling key 族补齐 + L0B 越界修复完成；
B=1 kvlen 至 32K、B≥2 多 batch 均 vs 官方 bit 级一致；MLA(C01 MTP_verify 形态) 支持且实测通过。

## 1. 内容地图

| 目录/文件 | 内容 |
|---|---|
| `op_src/` | **权威源码**（双算子 + 公共库，round_5 结档态；构建入口 `op_src/build.sh`） |
| `python/` | 调用入口 `fia_v2_sink_entry.py`（entry/metadata/SinkGraph） |
| `fia_v2_sink_ops-1.0-*.whl` | torch 扩展 wheel（= `delivery_round2/` 内同名件） |
| `delivery_round2/` | **编译产物（可用算子）**：`CANN-omni_custom_ops--linux.aarch64.run`（安装包）+ `opp/`（解压后即用，双条目 ASCEND_CUSTOM_OPP_PATH 指向它）+ sha256.txt + 构建日志 |
| `deploy_env.sh` / `deploy_env_92.sh` | 部署环境引导（9.1 / 9.2，双条目 ASCEND_CUSTOM_OPP_PATH） |
| `tests/` | 门禁：`case_builder.py`(C01–C20 MLA) / `gqa_case_builder.py`(C21–C26+mqa, GQA) / `check_gqa.py` / `run_gate*.sh` |
| `docs/` | 《FIA_v2_Sink_算子接口与实现说明》（接口/矩阵/契约/调用）；《FIA_Sink_合入vllm-ascend实施方案》（phase-1 设计，待实施） |
| `evidence/` | 包络权威登记 `r3_w1_gqa_boundary.json` + round_5 门禁脚本与日志 + round_4 GATE_SUMMARY |
| `handoff/` | 交接协议态 `cannbot_handoff.json`（round=2, done）+ 接入侧回执 `integration_feedback.md` |
| `okf_knowledge_pack/` | OKF 知识包（X47 双算子下沉 / F1 图重放 / F2 构建竞态 / F3 layout 契约 / 移植 runbook） |

## 2. 快速开始（部署 + 冒烟）

```bash
# 1) 环境（CANN 9.1）
source /usr/local/Ascend/ascend-toolkit/set_env.sh
# 2) 部署（双条目缺一不可）
pip3 install fia_v2_sink_ops-1.0-cp311-cp311-linux_aarch64.whl
export ASCEND_CUSTOM_OPP_PATH=$PWD/delivery_round2/opp/packages:$PWD/delivery_round2/opp/packages/vendors/omni_custom_transformer
# 3) 冒烟（NPU 卡自选；GQA D192 + MLA MTP_verify 两形态）
python3 tests/gqa_case_builder.py --check mqa_c27_g1_d192_tnd   # 须 bit_exact=True
python3 tests/case_builder.py --check C01                        # MLA verify 形态 须 PASS
```

构建（如需重编）：见 `docs/FIA_v2_Sink_算子接口与实现说明.md` §2 与 README；
**务必本地盘构建**（`cp -a op_src /tmp/... && cd /tmp/...`，NFS 竞态 F2）。

## 3. 必读契约（违反即静默出错，无报错）

1. **TND 累计 q-len**：`actual_seq_qlen` 传累计值 `[7,14,...]`，不是逐请求值——传错则非首请求输出全零。
2. **两段式**：主算子必带 `meta_data`（前置 metadata 算子产出）；aic/aiv 核数从 device properties 取。
3. **F3**：metadata 的 `input_layout_kv` 勿传 "TND_NTD"（传 "PA"/"TND"）。
4. **部署双条目**：`ASCEND_CUSTOM_OPP_PATH` 两条缺一不可。

## 4. 支持矩阵摘要（详见 docs/）

- GQA: D(qk,v,rope) = (128,128,0)/(64,64,0)/(128,64,64)/(192,128,0)/**(192,192,0)**；fp16/bf16
- MLA: D512+rope64、N2=1、rope 分离（C01=主模型 MTP_verify 形态）
- 布局：q TND/NTD_TND/BNSD/BSH；KV PA 池 4 维/3 维(BBH)/非 PA 连续
- batch ≥1（B=2/4/8 bit 验证）；kvlen B=1 至 32K
- 注记：D192×B≥2×kvlen≥4K 有 FD 分块序微小差（mere ~2e-05，非缺陷）

## 5. 已知遗留任务

见 `evidence/r3_w1_gqa_boundary.json`（update_round_4 节）与交接对话记录；要点：
非 PA 连续 KV 修复后复验、TND_NTD 组合布局 key、GQA sm1–4 门禁、量化族（W4A8 直连）、
C12–C17 性能演进（X47 双 stream/metadata 常驻）、vllm-ascend 源码合入实施（docs/ 方案 phase-2）。

## 6. 环境备注

- 本包在 AArch64 + Ascend910_93 + CANN 9.1.0 + torch_npu 2.10.0.post4 + python3.11 制作验证。
- 未包含：`install/custom/`（= delivery_round2/opp，可从 .run 重解压）、round_4 回滚基线
  （留在源机 `results/round_4_d192/rollback/`）、profiling 原始数据（`/home/t00886357/fia_sink/profiling/`）。
