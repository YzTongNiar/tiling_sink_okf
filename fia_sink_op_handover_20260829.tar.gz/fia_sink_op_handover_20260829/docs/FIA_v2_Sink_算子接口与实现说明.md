# FIA v2 Sink / Metadata 算子接口与实现说明

> 版本：round_5 结档态（对应交付包 `handoff/d192_fix2_delivery/`，2026-08-28）
> 适用二进制：d192_fix2_delivery（OPP + wheel 成对）；CANN 9.1.0 构建链路（9.2 兼容）
> 权威包络登记：`results/round_3/r3_w1_gqa_boundary.json`（update_round_4 节）；本文与其不一致时以 boundary json 为准

---

## 1. 架构概览

从 omni-ops `ai_infra_fused_infer_attention_sink(+_metadata)` 移植的**双算子形态**（OKF 策略 X47：AICPU tiling 下沉）：

```
┌────────────────────────────────────────┐ meta ┌─────────────────────────────────────┐
│ FusedInferAttentionScoreV2SinkMetadata  │ ───► │ FusedInferAttentionScoreV2Sink      │
│ (AICPU, DNN_VM_AICPU)                   │ GM   │ (AICore, MIX_AIC_1_2)               │
│ device 读 seq_len → SplitCore 同构分核  │      │ 读 GM 元数据驱动分核执行注意力      │
│ 写 uint32[1024] 元数据                  │      │ (host tiling 仅 shape-only)         │
└────────────────────────────────────────┘      └─────────────────────────────────────┘
```

- **设计目的**：seq_len 全程留在 device，D2H/H2D/aten::item 归零（profiler 实证）；主算子 host tiling 与数据值解耦（同 shape 不同值 → tiling 输出逐字节相同）。
- **ACLNN 名称**：`aclnnFusedInferAttentionScoreV2SinkMetadataV3`（前置）→ `aclnnFusedInferAttentionScoreV2SinkV3`（主，V3 版本号与官方 FIA 对齐）。
- **torch 入口**：`torch.ops.custom._npu_fused_infer_attention_score_v2_sink_metadata` / `torch.ops.custom.npu_fused_infer_attention_score_v2_sink`。
- **与官方 `npu_fused_infer_attention_score_v2` 的关系**：语义对齐（host list 传参基线改为 device tensor + 两段式），数学主体一致；门禁以与官方逐 bit 对照为标准。

## 2. 部署

```bash
# 1) torch 扩展（wheel 内含 python 入口与 aclnn 绑定）
pip3 install fia_v2_sink_ops-1.0-cp311-cp311-linux_aarch64.whl

# 2) 自定义算子库（双条目缺一不可：条目1 供 runtime 注册/加载 AICPU so，
#    条目2 供 torch 扩展解析 aclnn 符号 libcust_opapi.so）
export ASCEND_CUSTOM_OPP_PATH=<包>/packages:<包>/packages/vendors/omni_custom_transformer

# 3) CANN 环境
source /usr/local/Ascend/ascend-toolkit/set_env.sh        # 9.1 链路（本仓构建链）
# 或 /home/t00886357/ascend-9.2.0/cann/set_env.sh          # 9.2（9.1 构建包免重建兼容）
```

## 3. 主算子接口：`npu_fused_infer_attention_score_v2_sink`

### 3.1 输入（30 项，★ = Sink 服务形态必填/常用）

| # | 输入 | 形状/类型 | 说明 |
|---|---|---|---|
| 0 | ★ query | [T, N1, D]（TND）或 [N1, T, D]（NTD_TND） | T=Σqlen；bf16/fp16 |
| 1 | ★ key | PA 池 4 维 [pool, N2, BS, D]（BnNBsD）或 3 维 [pool, BS, N2×D]（BnBsH/BBH）；非 PA 连续 KV 亦支持 | bf16/fp16 |
| 2 | ★ value | 同 key（独立张量，GQA 非 MLA-absorbed） | |
| 3 | pse_shift | 可选 | 未启用 |
| 4 | atten_mask | 可选 | 未启用 |
| 5 | ★ actual_seq_lengths | **device INT64 [B]，TND 语义 = 累计值** [7,14,…] | ⚠️ 关键契约，见 §7.1 |
| 6 | ★ actual_seq_lengths_kv | device INT64 [B]，逐请求值 [20,45,…] | |
| 7–13 | dequant_scale1 / quant_scale1 / dequant_scale2 / quant_scale2 / quant_offset2 / antiquant_scale / antiquant_offset | 量化链路 | GQA 非 quant 不传 |
| 14 | ★ block_table | INT32 [B, bt_w]，页号（bt_w = 单请求最大页数） | PA 必填 |
| 15/16 | query_padding_size / kv_padding_size | 可选 | 未启用 |
| 17–20 | key/value_antiquant_scale/offset | 量化链路 | 不传 |
| 21/22 | ★ query_rope / key_rope | MLA 分离 rope | GQA 传 **None**（rope_head_dim=0 自动落 GQA 分支）；MLA 必传 |
| 23/24 | key_rope_antiquant_scale / dequant_scale_query | 量化链路 | 不传 |
| 25 | ★ **metadata** | uint32[1024]（前置算子输出） | **必填——缺失直接 aclnn 失败（两段式契约）** |
| 26–29 | learnable_sink / key_sink / key_rope_sink / value_sink | sink token 张量 | 当前门禁族未启用 |

### 3.2 输出（4 项）

| 输出 | 形状 | 说明 |
|---|---|---|
| attention_out | [T, N1, D]（TND；与 query 输入布局对应） | 与 q 同 dtype |
| softmax_lse | [N1, T] fp32（`return_softmax_lse=True` 时） | |
| softmax_max / softmax_sum | MLA 吸收方案专用（rope_split + vHeadDim=512） | GQA 不用 |

### 3.3 属性（19 项）

`num_heads`(N1)、`scale`(=1/√D)、`pre_tokens`、`next_tokens`、`input_layout`("TND"/"NTD_TND"/"BNSD"/"BSH"…)、`num_key_value_heads`(N2)、`sparse_mode`(已验证 0)、`inner_precise`、`block_size`(128)、`antiquant_mode` 系列、`softmax_lse_flag`、`pse_type`、`sink_number`、`batch_invariant`、`softmax_lse_max_sum`、`out_dtype`

## 4. 前置算子接口：`_npu_fused_infer_attention_score_v2_sink_metadata`

| 项 | 内容 |
|---|---|
| 输入（标量 6） | `num_heads_q`(N1)、`num_heads_kv`(N2)、`head_dim_qk`(D)、`head_dim_v`(vD) |
| 输入（tensor 2） | `actual_seq_lengths`（device INT64 [B] 累计）、`actual_seq_lengths_kv`（device INT64 [B]） |
| 输出 | `metaOut` uint32[1024]（布局：aic[36][10] 任务表 + aiv[72][3] + base[10]，见 `op_kernel/fused_infer_attention_score_v2_sink_metadata.h` 索引定义） |
| 属性（13） | `batch_size`、`sparse_mode`、`pre/next_tokens`、`input_layout`、**`input_layout_kv`**、`sink_num`/`k_sink_num`、`rope_head_dim`、`block_size`、**`aic_core_num`/`aiv_core_num`**、`batch_invariant` |

**契约与陷阱**：
- **F3**：`input_layout_kv` **勿传 "TND_NTD"/"NTD_TND"**（AICPU 字面量解析缺口，errcode 0x2a）；传 "PA"/"TND" 等价形态。
- **aic/aiv 核数必须由调用方从 `torch.npu.get_device_properties().aic_core_num` 等取**，勿用 schema 默认值（wrapper `metadata()` 已自动处理）。
- `batch_size=0` 表示从 seq len 张量长度推导。

## 5. 调用方法（三选一）

```python
# ① 推荐：entry() 两段式封装（python/fia_v2_sink_entry.py）
from fia_v2_sink_entry import entry
out, lse = entry(q, kpool, vpool,
    query_rope=None, key_rope=None,             # None → rope_head_dim=0 → GQA 分支
    num_query_heads=N1, num_key_value_heads=N2, # N2=None 时从 4 维池 shape[1] 自动派生
    input_layout="TND", input_layout_kv="PA",   # KV 连续布局按实际传（如 "TND"）
    sparse_mode=0, softmax_scale=1.0/math.sqrt(D),
    block_table=bt, block_size=128,
    actual_seq_qlen=qlen_dev_cum,               # device INT64 累计值 [7,14,...]（§7.1）
    actual_seq_kvlen=kvlen_dev,                 # device INT64 逐请求值 [20,45,...]
    return_softmax_lse=True)                    # → (out, lse)

# ② 显式两段（图模式复用 meta / 冒烟）：metadata() → torch.ops
from fia_v2_sink_entry import metadata
meta = metadata(N1, N2, D, vD, qlen_dev, kvlen_dev,
                input_layout="TND", input_layout_kv="PA", rope_head_dim=0,
                block_size=128, aic_core_num=aic, aiv_core_num=aiv)
out, lse = torch.ops.custom.npu_fused_infer_attention_score_v2_sink(
    q, k, v, query_rope=None, key_rope=None,
    actual_seq_qlen=qlen_dev, actual_seq_kvlen=kvlen_dev,
    block_table=bt, meta_data=meta,             # 必带
    num_query_heads=N1, num_key_value_heads=N2,
    input_layout="TND", sparse_mode=0, softmax_scale=scale, block_size=128,
    return_softmax_lse=True)

# ③ SinkGraph：aclgraph 捕获/重放封装 —— ⚠️ F1 FROZEN（失败模式已冻结）
#    平台限制：图重放不重执行 AICPU 定制节点 + 主算子捕获形态烘焙分核方案，
#    动态 seq 更新无法经图重放生效（9.1/9.2、MLA/GQA 同限）。
#    生产链路请使用 eager（①/②）。
```

## 6. 支持矩阵（当前二进制，round_5 结档）

| 维度 | 支持 | 验证状态 |
|---|---|---|
| 数据类型 | fp16 / bf16（非量化；q=kv=out 同型；lse fp32） | C01–C26 门禁 bit 绿 |
| GQA head 维度 (qk, v, rope) | (128,128,0)、(64,64,0)、(128,64,64)、**(192,128,0)、(192,192,0)**（round_4 新增 104 GENERAL 族） | D192 全套门禁 bit 绿 |
| MLA | qk=v=512 + rope=64（n2=1，rope 分离传输） | C01–C20 bit 绿 |
| q 布局 | TND、NTD_TND、BNSD、BSH/BSND（tiling key 全覆盖） | TND/NTD_TND bit 绿 |
| KV 形态 | PA 池 4 维 BnNBsD / 3 维 BnBsH（BBH）；非 PA 连续 KV | 两种 PA 池 bit 绿 |
| gSize（=N1/N2） | 运行时量，不进 tiling key：1–8+ 均可（MHA g=1 到 gS=8） | gS{1,2,4,6,8} bit 绿 |
| batch | **≥1 全支持**：B=2 等长/不等长、B=4 混合变长、B=8 已 bit 验证（对照官方逐请求 B=1 concat） | round_5 |
| kvlen | B=1 至 **32K**（bit 级）；B≥2 ≤248 bit 级；B≥2 ≥4K 见 §8 注记 | round_5 |
| sparse_mode | 0（门禁覆盖）；1–4 的 key 存在未在门禁族 | sm=0 |

**边界（不支持）**：
- TND_NTD 组合布局 GQA（无对应 tiling key）；
- 量化输入（GQA 族仅非量化；量化链路输入存在但未在门禁族）；
- vHeadDim 与上述组合不一致的形态（host `CheckGqaDSupport` 路由即拒）。

## 7. 输入契约与注意事项（排查优先级从高到低）

1. **TND 累计 q-len 契约**：`actual_seq_qlen` 必须传**累计值** `[qlen0, qlen0+qlen1, …]`。传逐请求值会导致解析器差分出 0/负数 → 任务被 SKIP → 非首请求输出**全零**（无任何报错）。排查 B≥2 异常第一步：核对调用方输入构造（正确示例见 `tests/gqa_case_builder.py` 的 `qlen_cum`）。
2. **两段式契约**：主算子必须带 `meta_data`（无 meta 直接 aclnn 失败）；aic/aiv 核数从 device properties 取。
3. **F3**：metadata 的 `input_layout_kv` 勿传组合布局字面量（"TND_NTD" 等），传 "PA"/"TND"。
4. **F1（eager-only）**：aclgraph 重放不重执行 AICPU 定制节点 + 主算子烘焙分核 → 动态 seq 更新在图模式下无效。生产链路 eager。
5. **F2（构建纪律）**：网络盘/NFS 上构建有竞态，必须 `cp -a` 到本地盘构建。
6. **部署双条目**：`ASCEND_CUSTOM_OPP_PATH` 两条缺一不可。

## 8. 行为注记（非缺陷）

| 场景 | 现象 | 性质 |
|---|---|---|
| D192 × B≥2 × kvlen≥~4K | sink 的 FD 分块负载均衡与官方 B=1 不同 → fp32 归约序差，mere ~2e-05 | ≪ bf16 分辨率 3.9e-3 与 P2 门限 7.8e-3；kvlen≤数百为 bit 级一致 |
| launch-bound 短负载 | 每 call 固定成本 ≈ AICPU 130–317µs + 双 aclnn 串行 150–190µs → 净亏 | 主 kernel ≳500µs 的 kernel-bound 负载净平/微赚（X47 成本判据） |
| golden（fp32 教科书）对照 | MERE_golden ~0.17（D192 bf16） | P2 参考口径，官方算子同偏；不作门禁 |

## 9. 关键路径

| 项 | 路径 |
|---|---|
| python 入口 | `python/fia_v2_sink_entry.py`（entry / metadata / SinkGraph） |
| 算子源码 | `op_src/src/ops-transformer/attention/fused_infer_attention_score_v2_sink{,_metadata}/` |
| 公共库（offset/memcopy/tiling 模板） | `op_src/src/ops-transformer/attention/common/` |
| 门禁与探针 | `tests/`（gqa_case_builder / check_gqa / run_gate_w1）+ `results/round_5_fix2/`（gate_kvlen / gate_b2_cum / gate_bN_cum） |
| 包络权威登记 | `results/round_3/r3_w1_gqa_boundary.json`（update_round_4 节） |
| 交付物 | `handoff/d192_fix2_delivery/`（round=2, status=done）；回滚基线 `results/round_4_d192/rollback/` |
| OKF 知识 | `skills/evolution-knowledge/references/okf/`（X47 / 移植 runbook / F1 / F2 / F3） |

---

*维护约定：本文档随交付轮次更新；接口契约变化（schema/entry 签名）必须同步修订 §3/§4 并在 handoff json 中显式声明。*
