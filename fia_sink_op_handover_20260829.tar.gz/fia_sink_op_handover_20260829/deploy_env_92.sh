#!/bin/bash
# 部署环境引导（CANN 9.2.0-beta.2 @ /home/t00886357/ascend-9.2.0）
# 用法: source deploy_env_92.sh [device_id]   （默认卡1：卡0 有显存挤占）
# 与 deploy_env.sh(9.1) 的差异：
#   ① 剥离 ~/.bashrc:100-101 注入的 9.1 路径（LD_LIBRARY_PATH 顺序敏感）
#   ② source 9.2 set_env.sh（前置覆盖，勿动 /usr/local/Ascend 只读红线 R3）
#   ③ 双条目 ASCEND_CUSTOM_OPP_PATH（同 9.1 模板）
#   ④ 默认卡1
set -u
TASK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
D92=/home/t00886357/ascend-9.2.0

# ① 剥离 bashrc 注入的 9.1（ascend-toolkit）与 nnal/atb 路径
strip_path_var() {
    local var="$1" val="" IFS=':' p e sep=""
    eval "val=\${$var:-}"
    local out=""
    for p in $val; do
        case "$p" in
            /usr/local/Ascend*) continue ;;
        esac
        out="${out}${sep}${p}"; sep=":"
    done
    # 剥离后保留空串（勿 unset：9.2 set_env.sh 在 set -u 下读未定义变量会中断）
    eval "export $var=\"$out\""
}
for v in PATH LD_LIBRARY_PATH PYTHONPATH LIBRARY_PATH; do strip_path_var "$v"; done

# 清掉 9.1 set_env 注入的版本锚点变量（防止残留指向 latest=9.1）
unset ASCEND_TOOLKIT_HOME ASCEND_HOME_PATH ASCEND_OPP_PATH ASCEND_AICPU_PATH \
      TOOLCHAIN_HOME ASCEND_CUSTOM_OPP_PATH ASCEND_ATC_VERSION 2>/dev/null || true

# ② source 9.2 环境（set_env.sh 内部按 9.2 路径前插）
export ASCEND_TOOLKIT_HOME="$D92/cann"
source "$D92/cann/set_env.sh"

# ③ 双条目 ASCEND_CUSTOM_OPP_PATH
# 条目1（含 vendors/ 的根）: 供 CANN runtime 注册算子 + 加载 AICPU so
# 条目2（vendor 目录本身）: 供 torch 扩展按 <entry>/op_api/lib/libcust_opapi.so 解析 aclnn 符号
export ASCEND_CUSTOM_OPP_PATH="$TASK_DIR/install/custom/packages:$TASK_DIR/install/custom/packages/vendors/omni_custom_transformer"

# ④ 选卡（默认卡1）
export ASCEND_RT_VISIBLE_DEVICES=${1:-1}

echo "[deploy_env_92] toolkit=$(readlink -f "$ASCEND_TOOLKIT_HOME")  dev=$ASCEND_RT_VISIBLE_DEVICES"
echo "[deploy_env_92] ASCEND_CUSTOM_OPP_PATH=$ASCEND_CUSTOM_OPP_PATH"
echo "[deploy_env_92] LD_LIBRARY_PATH 前3项: $(echo "${LD_LIBRARY_PATH:-}" | cut -d: -f1-3)"
