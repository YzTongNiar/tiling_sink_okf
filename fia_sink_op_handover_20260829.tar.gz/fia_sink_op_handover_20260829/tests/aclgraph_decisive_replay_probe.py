# 独立决定性实验：aclgraph 重放是否响应 device 侧 kvlen 原地更新
# 判据：r_fix(重放,更新后) 到底等于 eager(K2) 还是 eager(K1)
import sys, torch, torch_npu
sys.path.insert(0, "/mnt/share/t00886357/cannbot/fia-tiling-sink/npu_fused_infer_attention_score_v2_sink/python")
from fia_v2_sink_entry import entry, SinkGraph
import torch.nn.functional as F

DEV = "npu"
B, G, N1, N2 = 8, 8, 16, 1
D, DR, BS = 512, 64, 128
POOL = 1000
K1 = 2560   # 20 blocks/req
K2 = 5120   # 40 blocks/req —— 大差异，bit 判定无歧义
BT_W = 40
scale = 0.0721687836487032

torch.manual_seed(7)
q = (torch.rand(B * G, N1, D, dtype=torch.bfloat16) * 2).to(DEV)
qr = (torch.rand(B * G, N1, DR, dtype=torch.bfloat16) * 2).to(DEV)
kc = (torch.rand(POOL, N2, BS, D, dtype=torch.bfloat16) * 2).to(DEV)
kr = (torch.rand(POOL, N2, BS, DR, dtype=torch.bfloat16) * 2).to(DEV)
perm = torch.randperm(POOL)
bt = perm[: B * BT_W].reshape(B, BT_W).to(torch.int32).to(DEV)   # 每req 40 块 ≥ K2 需求
qlen = torch.tensor([G * (i + 1) for i in range(B)], dtype=torch.int64, device=DEV)
kvlen = torch.tensor([K1] * B, dtype=torch.int64, device=DEV)     # 捕获用持久 buffer（K1 初值）
# 互异要求（02 §6-3）：K1/K2 各自微扰
kvlen += torch.arange(B, device=DEV)

def eager(kv_vals):
    kv = torch.tensor(kv_vals, dtype=torch.int64, device=DEV)
    o, _ = entry(q, kc, kc, query_rope=qr, key_rope=kr, atten_mask=None,
                 block_table=bt, actual_seq_qlen=qlen, actual_seq_kvlen=kv,
                 num_query_heads=N1, num_key_value_heads=N2, input_layout="TND_NTD",
                 sparse_mode=0, softmax_scale=scale, block_size=BS, return_softmax_lse=True)
    torch.npu.synchronize()
    return o.clone()

K1v = (kvlen.cpu().tolist()); K2v = [v + K2 - K1 for v in K1v]
ref1 = eager(K1v)   # 捕获时刻值
ref2 = eager(K2v)   # 更新后期望值
d_ref = (ref1.float() - ref2.float()).abs().max().item()
print(f"[sanity] ref1 vs ref2 max_abs = {d_ref:.4f} (应 >> 0，否则实验无分辨力)", flush=True)
assert d_ref > 0.01

g = SinkGraph()
g.capture(q, kc, kc, query_rope=qr, key_rope=kr, atten_mask=None,
          block_table=bt, actual_seq_qlen=qlen, actual_seq_kvlen=kvlen,
          num_query_heads=N1, num_key_value_heads=N2, input_layout="TND_NTD",
          sparse_mode=0, softmax_scale=scale, block_size=BS, return_softmax_lse=True)

o0 = g.replay()[0].clone(); torch.npu.synchronize()
d0_1 = (o0.float() - ref1.float()).abs().max().item()
print(f"[固定输入重放] vs eager(K1) max_abs = {d0_1:.6f}  → {'一致' if d0_1 == 0 else '不一致'}", flush=True)

kvlen.copy_(torch.tensor(K2v, dtype=torch.int64, device=DEV))   # 原地更新（生产每步语义）
o1 = g.replay()[0].clone(); torch.npu.synchronize()
d1_2 = (o1.float() - ref2.float()).abs().max().item()
d1_1 = (o1.float() - ref1.float()).abs().max().item()
print(f"[更新kvlen后重放] vs eager(K2) max_abs = {d1_2:.6f} | vs eager(K1) max_abs = {d1_1:.6f}", flush=True)
verdict = "DYNAMIC_OK(更新生效)" if d1_2 == 0 and d1_1 > 0.01 else ("FROZEN(输出停在捕获值)" if d1_1 == 0 else "MIXED(部分生效)")
print(f"[判定] {verdict}", flush=True)

# 重捕获对照：证明捕获时刻用的是 live 值（排除"图根本不对"的解释）
kvlen2 = torch.tensor(K2v, dtype=torch.int64, device=DEV)
g2 = SinkGraph()
g2.capture(q, kc, kc, query_rope=qr, key_rope=kr, atten_mask=None,
           block_table=bt, actual_seq_qlen=qlen, actual_seq_kvlen=kvlen2,
           num_query_heads=N1, num_key_value_heads=N2, input_layout="TND_NTD",
           sparse_mode=0, softmax_scale=scale, block_size=BS, return_softmax_lse=True)
o2 = g2.replay()[0].clone(); torch.npu.synchronize()
d2_2 = (o2.float() - ref2.float()).abs().max().item()
print(f"[K2 重捕获+重放] vs eager(K2) max_abs = {d2_2:.6f} → {'捕获用 live 值' if d2_2 == 0 else '异常'}", flush=True)
print("EXP_DONE", flush=True)
