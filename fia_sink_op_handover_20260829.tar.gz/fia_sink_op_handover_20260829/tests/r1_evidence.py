"""R1/R3 形态证据采集（plans/03 §7.1）:
  a. profiler trace 中 AICPU 算子 FusedInferAttentionScoreV2SinkMetadata 每次 call 在 device 执行
  b. 同 shape 不同 kvlen → host tiling 无值依赖（tiling key 不变; 由 meta usedCoreNum 变化佐证分核真值来自 GM metadata）
  c. seq_len 相关 D2H/H2D = 0（profiler 无 aten::item / Memcpy D2H 记录）
输出 JSON: r1_evidence.json
"""
import json, os, sys
import torch
import torch_npu
from torch_npu.profiler import profile, ProfilerActivity

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "python"))
from case_builder import load_cases, parse_case, resolve, build_inputs, SCALE, LAYOUT  # noqa: E402
from fia_v2_sink_entry import entry, metadata  # noqa: E402

BASE_OFF = 36 * 10 + 72 * 3


def run(out_json):
    cases = load_cases()
    c = parse_case(cases[resolve(cases, "C01")])
    inp = build_inputs(c)
    kw = dict(query_rope=inp["qpe"], key_rope=inp["krpool"],
              num_query_heads=c["H"], num_key_value_heads=c["kvh"],
              input_layout=LAYOUT, sparse_mode=c["sparse_mode"], softmax_scale=inp["scale"],
              block_table=inp["bt"], block_size=c["BS"],
              actual_seq_qlen=inp["qlen_dev"], actual_seq_kvlen=inp["kvlen_dev"],
              return_softmax_lse=False)
    if c["use_mask"]:
        kw["atten_mask"] = inp["mask"]

    # ---- (b) meta usedCoreNum 随 kvlen 变化（同 shape） ----
    kv_variants = []
    for delta in (0, 8, 64, 512, 4096):
        kv = inp["kvlen_dev"] + delta
        m = metadata(c["H"], c["kvh"], c["D"], c["D"], inp["qlen_dev"], kv,
                     sparse_mode=c["sparse_mode"], input_layout=LAYOUT, input_layout_kv="PA",
                     rope_head_dim=c["R"], block_size=c["BS"])
        torch.npu.synchronize()
        mc = m.cpu()
        kv_variants.append(dict(delta=delta, usedCoreNum=int(mc[BASE_OFF + 4]),
                                s2Size=int(mc[BASE_OFF + 7]), numOfFd=int(mc[BASE_OFF + 3])))
    used_core_changes = len({v["usedCoreNum"] for v in kv_variants}) > 1 or len({v["s2Size"] for v in kv_variants}) > 1

    # ---- (a)/(c) profiler: 新算子连续 8 次调用 ----
    with profile(activities=[ProfilerActivity.CPU, ProfilerActivity.NPU]) as prof:
        for _ in range(8):
            entry(inp["q"], inp["kpool"], inp["kpool"], **kw)
        torch.npu.synchronize()

    os.makedirs("/tmp/fia_prof", exist_ok=True)
    prof.export_chrome_trace("/tmp/fia_prof/trace.json")

    # chrome trace 解析（prof.events() 在本版本不可用）
    raw = json.load(open("/tmp/fia_prof/trace.json"))
    tr = raw if isinstance(raw, list) else raw.get("traceEvents", [])
    ev = [e for e in tr if isinstance(e, dict) and e.get("ph") == "X"]
    def name_of(e):
        return str(e.get("name", ""))
    meta_calls = [e for e in ev if "Metadata" in name_of(e) and "FusedInferAttentionScoreV2Sink" in name_of(e)
                  and "Dequeue" not in name_of(e) and "Enqueue" not in name_of(e)]
    d2h = [e for e in ev if ("Memcpy" in name_of(e) and ("DtoH" in name_of(e) or "Device to Host" in name_of(e)))
           or name_of(e) == "aten::item"]
    h2d = [e for e in ev if "Memcpy" in name_of(e) and ("HtoD" in name_of(e) or "Host to Device" in name_of(e))]

    r = dict(
        meta_kernel=dict(
            observed_names=sorted({name_of(e) for e in meta_calls})[:4],
            call_count=len(meta_calls), expected_calls=8,
            aicpu_executed=len(meta_calls) >= 8),
        d2h_count=len(d2h), h2d_count=len(h2d),
        d2h_sample=[name_of(e) for e in d2h[:3]],
        h2d_sample=[name_of(e) for e in h2d[:3]],
        same_shape_kvlen_variants=kv_variants,
        used_core_or_s2_changes_with_kvlen=used_core_changes,
        zero_seq_d2h_h2d=(len(d2h) == 0),
        trace="/tmp/fia_prof/trace.json",
    )
    r["r1_holds"] = r["meta_kernel"]["aicpu_executed"] and used_core_changes
    r["r3_holds"] = len(d2h) == 0
    print(json.dumps(r, indent=1, ensure_ascii=False))
    if out_json:
        json.dump(r, open(out_json, "w"), indent=1)


if __name__ == "__main__":
    run(sys.argv[1] if len(sys.argv) > 1 else None)
