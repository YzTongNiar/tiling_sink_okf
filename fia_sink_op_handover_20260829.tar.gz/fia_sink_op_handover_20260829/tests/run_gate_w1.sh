#!/bin/bash
# W1 GQA 门禁 runner（plans/08 §3.2；run_gate.sh 风格：逐条进程隔离，JSON → results/）
# 与 run_gate.sh 的差异：source deploy_env_92.sh（CANN 9.2 环境），用例族 C21–C26/S1/S2/V1V3/V5。
# 独立成脚本而非扩展 run_gate.sh，以保证 P1 回归入口零改动、9.1/9.2 环境互不污染。
# 用法: bash run_gate_w1.sh <round_dir> [device_id] [phase]
#   phase = all | prec | bench | evidence | graph
set -u
ROUND_DIR=${1:?round dir}
DEV=${2:-1}
PHASE=${3:-all}
HERE=$(cd "$(dirname "$0")" && pwd)
TASK_DIR=$(cd "$HERE/.." && pwd)
mkdir -p "$ROUND_DIR"
export ASCEND_RT_VISIBLE_DEVICES=$DEV
# 9.2 部署环境（双条目 ASCEND_CUSTOM_OPP_PATH；勿 source deploy_env.sh——那是 9.1）
source "$TASK_DIR/deploy_env_92.sh" "$DEV" > /dev/null

PY=python3
GQACASES="C21 C22 C23 C24 C25 C26"
STRESS="S1 S2"

run_retry() {  # 失败重试 <=2
  local n=0
  until "$@"; do
    n=$((n+1)); [ $n -ge 3 ] && return 1
    echo "[retry $n] $*"
    sleep 2
  done
}

if [ "$PHASE" = all ] || [ "$PHASE" = prec ]; then
  echo "== GQA precision gate C21-C26 + MQA anchor =="
  for c in $GQACASES; do
    run_retry $PY "$HERE/check_gqa.py" "$c" --json "$ROUND_DIR/prec_$c.json" || echo "PREC-$c FAILED" >> "$ROUND_DIR/failures_w1.txt"
  done
  run_retry $PY - <<EOF || echo "MQA FAILED" >> "$ROUND_DIR/failures_w1.txt"
import sys
sys.path.insert(0, "$HERE")
from check_gqa import mqa_check
sys.exit(0 if mqa_check() else 1)
EOF
fi

if [ "$PHASE" = all ] || [ "$PHASE" = bench ]; then
  echo "== V4 kernel-bound stress =="
  for c in $STRESS; do
    run_retry $PY "$HERE/bench_gqa.py" --cases "$c" --impl baseline --iters 10 --json "$ROUND_DIR/base_$c.json" || echo "BENCH-BASE-$c FAILED" >> "$ROUND_DIR/failures_w1.txt"
    run_retry $PY "$HERE/bench_gqa.py" --cases "$c" --impl newop --iters 10 --json "$ROUND_DIR/new_$c.json" || echo "BENCH-NEW-$c FAILED" >> "$ROUND_DIR/failures_w1.txt"
  done
fi

if [ "$PHASE" = all ] || [ "$PHASE" = evidence ]; then
  echo "== V1 metadata / V3 profiler diff =="
  run_retry $PY "$HERE/w1_gqa_evidence.py" "$ROUND_DIR/r3_w1_v1v3_gqa.json" || echo "EVIDENCE FAILED" >> "$ROUND_DIR/failures_w1.txt"
fi

if [ "$PHASE" = all ] || [ "$PHASE" = graph ]; then
  echo "== V5 aclgraph replay probe (GQA form) =="
  run_retry $PY "$HERE/aclgraph_gqa_replay_probe.py" > >(tee "$ROUND_DIR/r3_w1_v5_graph_gqa_probe.log") 2>/dev/null || echo "GRAPH FAILED" >> "$ROUND_DIR/failures_w1.txt"
fi

echo "== W1 gate done: $ROUND_DIR =="
[ -f "$ROUND_DIR/failures_w1.txt" ] && { echo "FAILURES:"; cat "$ROUND_DIR/failures_w1.txt"; exit 1; } || echo "ALL RUNS COMPLETED"
