"""FIA v2 基线/新算子性能对比压测。

对比口径 (务必遵守):
  - baseline : 官方 npu_fused_infer_attention_score_v2, actual_seq_qlen/kvlen 传 **host list** (保持原样)
  - newop    : 生成的 tiling 下沉算子, actual_seq_qlen/kvlen 传 **device tensor**
  - 性能目标 : newop device p50 / baseline device p50 <= 1.0x (不劣于基线即达标)

每次迭代必须跑全部 11 条用例 (含 C11 门禁)。输出 JSON 归档, 供 04 流程做回归对比。

用法:
  python3 bench_baseline.py                       # 全部 11 条, baseline
  python3 bench_baseline.py --cases C01 C02 C11 --impl newop   # 新算子接入后
  python3 bench_baseline.py --compare old.json new.json         # 对比 + 1x 判定
"""
import argparse, json, os, sys, time
import torch
import torch_npu
from case_builder import load_cases, parse_case, build_inputs, call_baseline, resolve, mere, GOLDEN_MERE_TH, LAYOUT
import case_builder


def call_baseline_dev(inp):
    """口径保险: 基线算子本身也接受 device tensor 传参 (torch API 原生支持)。
    主口径仍为 baseline=host list vs newop=device tensor。"""
    saved_q, saved_k = inp["qlen_host"], inp["kvlen_host"]
    inp["qlen_host"], inp["kvlen_host"] = inp["qlen_dev"], inp["kvlen_dev"]
    try:
        return call_baseline(inp)
    finally:
        inp["qlen_host"], inp["kvlen_host"] = saved_q, saved_k

TARGET_RATIO = 1.0          # 性能目标: 达到基线 1x
DEFAULT_ITERS = 20
GATE_ITERS = 5              # C11 门禁用例压测次数


import os, sys as _sys
_sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "python"))
from fia_v2_sink_entry import entry as _sink_entry  # noqa: E402


def call_newop(inp):
    """新算子 npu_fused_infer_attention_score_v2_sink（AICPU tiling 下沉, device seq len）。
    入参与 baseline 完全一致, 仅 actual_seq_qlen/kvlen 改传 inp['qlen_dev']/inp['kvlen_dev'];
    entry() 内含 metadata 前置调用（两段式）。"""
    c = inp["case"]
    kw = dict(
        query_rope=inp["qpe"], key_rope=inp["krpool"],
        num_query_heads=c["H"], num_key_value_heads=c["kvh"],
        input_layout=LAYOUT, sparse_mode=c["sparse_mode"],
        softmax_scale=inp["scale"], block_table=inp["bt"], block_size=c["BS"],
        actual_seq_qlen=inp["qlen_dev"], actual_seq_kvlen=inp["kvlen_dev"],
        return_softmax_lse=False,
    )
    if c["use_mask"]:
        kw["atten_mask"] = inp["mask"]
    return _sink_entry(inp["q"], inp["kpool"], inp["kpool"], **kw)


def bench_case(name, impl="baseline", warmup=3, iters=None):
    c = parse_case(load_cases()[name])
    n = iters or (GATE_ITERS if c["gate"] else DEFAULT_ITERS)
    inp = build_inputs(c)
    call = {"baseline": call_baseline, "baseline_dev": call_baseline_dev}.get(impl, call_newop)
    for _ in range(warmup):
        call(inp)
    torch.npu.synchronize()

    dev_us, host_us = [], []
    for _ in range(n):
        s = torch.npu.Event(enable_timing=True); e = torch.npu.Event(enable_timing=True)
        t0 = time.perf_counter()          # host 路径: 含 list->tensor / workspace / tiling / launch
        s.record()
        call(inp)
        e.record()
        host_us.append((time.perf_counter() - t0) * 1e6)
        dev_us.append(s.elapsed_time(e) * 1e3)
    torch.npu.synchronize()

    # host->device 拷贝探针: 基线每调用需把两个 list 落到 device
    t0 = time.perf_counter()
    for _ in range(n):
        torch.tensor(inp["qlen_host"], dtype=torch.int64, device=inp["q"].device)
        torch.tensor(inp["kvlen_host"], dtype=torch.int64, device=inp["q"].device)
    torch.npu.synchronize()
    h2d_us = (time.perf_counter() - t0) / n * 1e6

    dev_us.sort(); host_us.sort()
    r = dict(case=name, impl=impl, gate=c["gate"], n=n,
             device_p50_us=dev_us[len(dev_us) // 2], device_min_us=dev_us[0],
             host_p50_us=host_us[len(host_us) // 2], h2d_probe_us=round(h2d_us, 2))
    return r


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", nargs="*", default=None)
    ap.add_argument("--impl", default="baseline", choices=["baseline", "baseline_dev", "newop"])
    ap.add_argument("--iters", type=int, default=None)
    ap.add_argument("--json", default=None)
    ap.add_argument("--compare", nargs=2, metavar=("BASE_JSON", "NEW_JSON"))
    a = ap.parse_args()

    if a.compare:
        base = {r["case"]: r for r in json.load(open(a.compare[0]))}
        new = {r["case"]: r for r in json.load(open(a.compare[1]))}
        print(f"{'case':20s} {'base_p50(us)':>13s} {'new_p50(us)':>12s} {'ratio':>7s}  gate")
        all_pass = True
        for n, r in new.items():
            b = base[n]["device_p50_us"]
            ratio = r["device_p50_us"] / b
            need = "GATE<=1.0" if r["gate"] or n in ("C01_sig_a_typical", "C02_sig_b_typical") else "<=1.1"
            ok = ratio <= (TARGET_RATIO if "GATE" in need or n.startswith(("C01", "C02")) else 1.1)
            all_pass &= ok
            print(f"{n:20s} {b:13.1f} {r['device_p50_us']:12.1f} {ratio:7.3f}  {'PASS' if ok else 'FAIL'} {need}")
        print("OVERALL:", "PASS" if all_pass else "FAIL")
        sys.exit(0 if all_pass else 1)

    names = [resolve(load_cases(), n) for n in (a.cases or list(load_cases()))]
    rows = []
    for n in names:
        r = bench_case(n, impl=a.impl, iters=a.iters)
        rows.append(r)
        print(f"[{n:20s}] device_p50={r['device_p50_us']:9.1f}us  min={r['device_min_us']:9.1f}us  "
              f"host_p50={r['host_p50_us']:7.1f}us  h2d={r['h2d_probe_us']:6.1f}us  (n={r['n']}, {a.impl})")
    if a.json:
        json.dump(rows, open(a.json, "w"), indent=1)
        print("saved ->", a.json)


if __name__ == "__main__":
    main()
