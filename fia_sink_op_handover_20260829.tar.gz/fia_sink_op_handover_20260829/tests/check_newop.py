"""npu_fused_infer_attention_score_v2_sink 精度门禁（plans/05 §4）。

逐条进程隔离执行（每条一进程）:
  python3 check_newop.py C01 --json results/round_1/prec_C01.json

判据:
  1. 主判据: 新算子 vs fp32 golden, MERE < 2^-7 且输出有限
  2. 强判据: 新算子 vs 基线（host list 同输入）allclose(BF16 rtol 1e-2/atol 1e-3) 或 cos >= 0.999
  3. lse: fp32, 与 golden lse 相对误差 < 1e-3
  4. R1 证据: meta tensor 关键字（usedCoreNum/s1Size/s2Size 随 kvlen 变化）随 JSON 归档
"""
import argparse, json, math, os, sys
import torch
import torch_npu  # noqa: F401

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "python"))
from case_builder import load_cases, parse_case, resolve, build_inputs, call_baseline, golden, mere, GOLDEN_MERE_TH, SCALE, LAYOUT  # noqa: E402
from fia_v2_sink_entry import entry, metadata  # noqa: E402

# FiaSinkMetaData flat 布局（op_kernel/fused_infer_attention_score_v2_sink_metadata.h）
AIV_OFF = 36 * 10
BASE_OFF = AIV_OFF + 72 * 3
BASE_IDX = dict(mBaseSize=0, sInnerSize=1, mFdBaseSize=2, numOfFd=3, usedCoreNum=4,
                usedVecNumOfFd=5, s1Size=6, s2Size=7, actualLenQDims=8, actualLenKvDims=9)


def meta_evidence(meta_cpu):
    ev = {}
    for k, i in BASE_IDX.items():
        ev[k] = int(meta_cpu[BASE_OFF + i].item())
    aic_enable = [int(meta_cpu[c * 10 + 0].item()) for c in range(36)]
    ev["aic_enabled_count"] = sum(aic_enable)
    return ev


def golden_lse(inp):
    """fp32 golden lse: [T]（token 维）。"""
    c = inp["case"]
    B, G, H, D, R, BS = c["B"], c["G"], c["H"], c["D"], c["R"], c["BS"]
    q, qpe = inp["q"].float(), inp["qpe"].float()
    kpool = inp["kpool"].float().reshape(-1, BS, D)
    krpool = inp["krpool"].float().reshape(-1, BS, R)
    btc = inp["bt"] if not inp["bt"].is_npu else inp["bt"].cpu()
    lse = torch.zeros(c["T"])
    for i, L in enumerate(c["kvlen"]):
        nb = math.ceil(L / BS)
        ids = btc[i, :nb].long()
        klat = kpool[ids].reshape(-1, D)[:L]
        krope = krpool[ids].reshape(-1, R)[:L]
        for j in range(G):
            t = i * G + j
            s = (q[t] @ klat.T + qpe[t] @ krope.T) * inp["scale"]  # [H, L]
            if c["sparse_mode"] != 0:
                lim = L - G + j + 1
                s[:, lim:] = float("-inf")
            m = s.max(dim=-1).values
            lse[t] = (m + torch.log(torch.exp(s - m.unsqueeze(1)).sum(dim=-1))).mean()  # 头均值
    return lse


def check(name, json_out=None):
    cases = load_cases()
    c = parse_case(cases[resolve(cases, name)])
    inp = build_inputs(c)

    # ---- 新算子（两段式, device 传参） ----
    kw = dict(query_rope=inp["qpe"], key_rope=inp["krpool"],
              num_query_heads=c["H"], num_key_value_heads=c["kvh"],
              input_layout=LAYOUT, sparse_mode=c["sparse_mode"], softmax_scale=inp["scale"],
              block_table=inp["bt"], block_size=c["BS"],
              actual_seq_qlen=inp["qlen_dev"], actual_seq_kvlen=inp["kvlen_dev"],
              return_softmax_lse=True)
    if c["use_mask"]:
        kw["atten_mask"] = inp["mask"]
    out_n, lse_n = entry(inp["q"], inp["kpool"], inp["kpool"], **kw)

    # R1 证据: metadata 关键字段
    meta = metadata(c["H"], c["kvh"], c["D"], c["D"], inp["qlen_dev"], inp["kvlen_dev"],
                    sparse_mode=c["sparse_mode"], input_layout=LAYOUT, input_layout_kv="PA",
                    rope_head_dim=c["R"], block_size=c["BS"])
    torch.npu.synchronize()
    ev = meta_evidence(meta.cpu())

    # ---- 基线（host list 传参, 原样不动） ----
    out_b, lse_b = call_baseline(inp, return_lse=True)
    torch.npu.synchronize()

    # ---- fp32 golden（CPU 侧计算: 避免长序列 pool 的设备侧 fp32 转换爆显存, C20 pool fp32 ≈ 1GB） ----
    inp_cpu = {k: (v.cpu() if torch.is_tensor(v) and v.is_npu else v) for k, v in inp.items()}
    ref = golden(inp_cpu).to(out_n.device)

    m_g, mx_g = mere(out_n, ref)
    finite = bool(torch.isfinite(out_n.float()).all().item())
    a = out_n.float().flatten(); b = out_b.float().flatten()
    cos = torch.nn.functional.cosine_similarity(a.unsqueeze(0), b.unsqueeze(0)).item()
    m_b, _ = mere(out_n, out_b)
    allclose = bool(torch.allclose(out_n.float(), out_b.float(), rtol=1e-2, atol=1e-3))

    # lse 判定（布局按 plans/05 §3: 与基线逐元素对齐后再判差）
    lse_ok, lse_rel = None, None
    if lse_n is not None and lse_n.numel() > 1 and lse_b.numel() > 1:
        ln = lse_n.squeeze(-1).float()   # 基线 TND_NTD 实测 [heads, tokens, 1] -> squeeze 后 [H, T]
        lb = lse_b.squeeze(-1).float()
        if ln.dim() == 2 and lb.dim() == 2 and ln.shape != lb.shape:
            ln = ln.reshape(-1); lb = lb.reshape(-1)   # [H,T] vs [T,H] 情形按需转置
            if ln.numel() == lb.numel() and not torch.allclose(ln, lb, rtol=1e-3, atol=1e-3):
                ln2 = ln.reshape(lb.shape)
                if torch.allclose(ln2, lb, rtol=1e-2, atol=1e-2):
                    ln = ln2
        if ln.shape == lb.shape:
            lse_rel = ((ln - lb).abs() / lb.abs().clamp_min(1e-6)).mean().item()
            lse_ok = lse_rel < 1e-3
        else:
            lse_ok = False

    main_ok = m_g < GOLDEN_MERE_TH and finite
    strong_ok = allclose or cos >= 0.999
    passed = main_ok and strong_ok and (lse_ok in (None, True))

    r = dict(case=c["name"], shape=tuple(out_n.shape),
             mere_vs_golden=m_g, max_abs_vs_golden=mx_g, finite=finite,
             mere_vs_baseline=m_b, cos_vs_baseline=cos, allclose_vs_baseline=allclose,
             lse_rel_err=lse_rel, lse_shape_new=tuple(lse_n.shape) if lse_n is not None else None,
             lse_shape_base=tuple(lse_b.shape),
             meta_evidence=ev,
             main_ok=main_ok, strong_ok=strong_ok, lse_ok=lse_ok, passed=passed)
    print(f"[{name}] shape={r['shape']} MERE_golden={m_g:.6f} cos_base={cos:.8f} "
          f"allclose={allclose} lse_rel={lse_rel} PASS={passed}")
    print(f"    meta: {ev}")
    if json_out:
        os.makedirs(os.path.dirname(os.path.abspath(json_out)), exist_ok=True)
        json.dump(r, open(json_out, "w"), indent=1)
    return passed


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("cases", nargs="*")
    ap.add_argument("--json", default=None)
    a = ap.parse_args()
    names = a.cases or [f"C{i:02d}" for i in range(1, 21)]
    if len(names) == 1 and a.json:
        ok = check(names[0], a.json)
    else:
        ok = all([check(n) for n in names])
    sys.exit(0 if ok else 1)
