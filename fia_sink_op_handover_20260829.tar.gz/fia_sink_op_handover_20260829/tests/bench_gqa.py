"""FIA v2 sink GQA 性能压测（V4 门禁, plans/08 §3.2）。

口径与 bench_sink.py 完全一致:
  - baseline : 官方 npu_fused_infer_attention_score_v2 GQA 路径, seq len 传 host list
  - newop    : sink 两段式 entry, seq len 传 device INT64
  - 判定     : kernel-bound 压测族 newop/baseline ≥ 1x 视为达标（device p50, iters=10）

用法:
  python3 bench_gqa.py --cases S1 --impl baseline --iters 10 --json ../results/round_3/base_S1.json
"""
import argparse, json, os, sys, time
import torch
import torch_npu

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "python"))
from gqa_case_builder import resolve, parse_case, build_inputs, call_baseline, call_newop  # noqa: E402

GATE_ITERS = 10


def bench_case(name, impl="baseline", warmup=3, iters=None):
    c = parse_case(resolve(name))
    n = iters or GATE_ITERS
    inp = build_inputs(c)
    call = call_baseline if impl == "baseline" else call_newop

    kw_no_lse = None
    if impl == "newop":
        # 与 check 路径一致但关闭 lse 输出（性能主口径）
        def call(inp):
            return call_newop(inp, return_lse=False)[0]
    for _ in range(warmup):
        call(inp)
        torch.npu.synchronize()

    dev_us, host_us = [], []
    for _ in range(n):
        s = torch.npu.Event(enable_timing=True)
        e = torch.npu.Event(enable_timing=True)
        t0 = time.perf_counter()
        s.record()
        call(inp)
        e.record()
        torch.npu.synchronize()
        host_us.append((time.perf_counter() - t0) * 1e6)
        dev_us.append(s.elapsed_time(e) * 1e3)

    dev_us.sort()
    host_us.sort()
    return dict(case=name, impl=impl, n=n,
                device_p50_us=dev_us[len(dev_us) // 2], device_min_us=dev_us[0],
                host_p50_us=host_us[len(host_us) // 2])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", nargs="*", required=True)
    ap.add_argument("--impl", default="baseline", choices=["baseline", "newop"])
    ap.add_argument("--iters", type=int, default=None)
    ap.add_argument("--json", default=None)
    a = ap.parse_args()
    rows = []
    for nm in a.cases:
        r = bench_case(nm, a.impl, iters=a.iters)
        rows.append(r)
        print(f"[{nm} ({a.impl})] device_p50={r['device_p50_us']:9.1f}us "
              f"min={r['device_min_us']:9.1f}us host_p50={r['host_p50_us']:8.1f}us")
    if a.json:
        os.makedirs(os.path.dirname(os.path.abspath(a.json)) or ".", exist_ok=True)
        json.dump(rows, open(a.json, "w"), indent=1)
        print("saved ->", a.json)


if __name__ == "__main__":
    main()
