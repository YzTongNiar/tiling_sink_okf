"""门禁汇总: 合并 round 目录下 base_*.json / new_*.json / prec_*.json / graph_*.json,
输出 plans/05 §5-§7 判定表 + gate_summary.json。

用法: python3 summarize_gate.py <round_dir>
"""
import json, os, sys

HARD = {"C11"} | {f"C{i}" for i in range(12, 21)}   # 硬门族: <=1.0 (tol 1.05)
C01_C10 = [f"C{i:02d}" for i in range(1, 11)]
ALL = C01_C10 + ["C11"] + [f"C{i:02d}" for i in range(12, 21)]


def key_of(fname):
    # base_C01.json -> C01 ; prec_C12_r12_kv128k.json 兼容
    b = os.path.basename(fname)
    for part in b.replace(".json", "").split("_"):
        if part.startswith("C") and part[1:].isdigit():
            return part
    return None


def load(round_dir, prefix):
    out = {}
    for f in os.listdir(round_dir):
        if f.startswith(prefix + "_") and f.endswith(".json"):
            k = key_of(f)
            if k:
                try:
                    data = json.load(open(os.path.join(round_dir, f)))
                    if isinstance(data, list) and data:
                        data = data[0]   # bench json 为单条 list
                    out[k] = data
                except Exception:
                    pass
    return out


def main(round_dir):
    base = load(round_dir, "base")
    new = load(round_dir, "new")
    prec = load(round_dir, "prec")
    graph = {}
    for g in ("G1", "G2", "G3"):
        p = os.path.join(round_dir, f"graph_{g}.json")
        if os.path.exists(p):
            graph[g] = json.load(open(p))

    rows = []
    print(f"{'case':6s} {'base_p50':>9s} {'new_p50':>9s} {'ratio':>7s} {'hard?':>5s} {'perf':>5s} {'prec':>5s}")
    all_perf_ok, all_prec_ok = True, True
    ratios = {}
    for c in ALL:
        b = base.get(c, {}).get("device_p50_us")
        n = new.get(c, {}).get("device_p50_us")
        pr = prec.get(c, {})
        if b is None or n is None:
            print(f"{c:6s} {'-':>9s} {'-':>9s} {'-':>7s} {'Y' if c in HARD else 'n':>5s} {'MISS':>5s}")
            all_perf_ok = False
            continue
        ratio = n / b
        ratios[c] = ratio
        limit = 1.05 if c in HARD else 1.10
        perf_ok = ratio <= limit
        all_perf_ok &= perf_ok
        prec_ok = pr.get("passed")
        all_prec_ok &= (prec_ok is not False) if pr else False
        if prec_ok is None and not pr:
            all_prec_ok = False
        print(f"{c:6s} {b:9.1f} {n:9.1f} {ratio:7.3f} {'Y' if c in HARD else 'n':>5s} "
              f"{'PASS' if perf_ok else 'FAIL':>5s} {str(prec_ok):>5s}")

    graph_ok = all(g.get("passed") for g in graph.values()) if graph else False
    if graph:
        for g, r in graph.items():
            extra = f" ratio={r.get('ratio'):.3f}" if "ratio" in r and r.get("ratio") else ""
            print(f"{g}: passed={r.get('passed')}{extra}")

    summary = dict(
        round_dir=round_dir,
        perf={c: dict(base_us=base.get(c, {}).get("device_p50_us"),
                      new_us=new.get(c, {}).get("device_p50_us"),
                      ratio=ratios.get(c),
                      hard=(c in HARD),
                      passed=(ratios.get(c) is not None and ratios[c] <= (1.05 if c in HARD else 1.10))) for c in ALL if c in ratios},
        precision={c: dict(passed=v.get("passed"), mere=v.get("mere_vs_golden"), cos=v.get("cos_vs_baseline"),
                           meta=v.get("meta_evidence")) for c, v in prec.items()},
        graph={g: v for g, v in graph.items()},
        all_perf_ok=all_perf_ok,
        all_prec_ok=all_prec_ok,
        all_graph_ok=graph_ok,
        gate_pass=all_perf_ok and all_prec_ok and graph_ok,
    )
    out = os.path.join(round_dir, "gate_summary.json")
    json.dump(summary, open(out, "w"), indent=1)
    print(f"\nOVERALL: perf={'PASS' if all_perf_ok else 'FAIL'} prec={'PASS' if all_prec_ok else 'FAIL'} "
          f"graph={'PASS' if graph_ok else ('PENDING' if not graph else 'FAIL')}")
    print("saved ->", out)
    return 0 if summary["gate_pass"] else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
