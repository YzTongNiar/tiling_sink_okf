"""G1-G3 图模式门禁（plans/05 §2.4, R2: 两算子 aclgraph 入图）。

逐条进程隔离执行:
  python3 graph_cases.py G1 --json results/round_1/graph_G1.json

  G1: C01 shape 捕获一图; replay 24 步, 每步 kvlen+=8 原地 copy_; 逐步输出与同输入 eager cos=1.0;
      输出随更新变化（非固化）
  G2: C11 shape 同上 + replay 性能 (device_p50 ≤ eager 目标 / 1.05 上限)
  G3: C01 shape 变 qlen: replay 中 qlen MTP-8→MTP-7 + 末 batch kvlen 置 0（T 轴 padding）; 无崩溃;
      有效 batch 输出与 eager 一致
"""
import argparse, json, os, sys, time
import torch
import torch_npu  # noqa: F401

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "python"))
from case_builder import load_cases, parse_case, resolve, build_inputs, SCALE, LAYOUT  # noqa: E402
from fia_v2_sink_entry import SinkGraph, entry  # noqa: E402


def eager_call(inp, qlen, kvlen, lse=True):
    c = inp["case"]
    kw = dict(query_rope=inp["qpe"], key_rope=inp["krpool"],
              num_query_heads=c["H"], num_key_value_heads=c["kvh"],
              input_layout=LAYOUT, sparse_mode=c["sparse_mode"], softmax_scale=inp["scale"],
              block_table=inp["bt"], block_size=c["BS"],
              actual_seq_qlen=qlen, actual_seq_kvlen=kvlen,
              return_softmax_lse=lse)
    if c["use_mask"]:
        kw["atten_mask"] = inp["mask"]
    return entry(inp["q"], inp["kpool"], inp["kpool"], **kw)


def cos_of(a, b):
    return torch.nn.functional.cosine_similarity(
        a.float().flatten().unsqueeze(0), b.float().flatten().unsqueeze(0)).item()


def bench(fn, warmup=3, iters=20):
    for _ in range(warmup):
        fn()
    torch.npu.synchronize()
    dev_us = []
    for _ in range(iters):
        s = torch.npu.Event(enable_timing=True); e = torch.npu.Event(enable_timing=True)
        s.record(); fn(); e.record()
        torch.npu.synchronize()
        dev_us.append(s.elapsed_time(e) * 1e3)
    dev_us.sort()
    return dev_us[len(dev_us) // 2]


def run_case(g, json_out=None):
    cases = load_cases()
    if g == "G1":
        case_name = "C01"
    elif g == "G2":
        case_name = "C11"
    elif g == "G3":
        case_name = "C01"
    else:
        raise ValueError(g)
    c = parse_case(cases[resolve(cases, case_name)])
    inp = build_inputs(c)
    B, G = c["B"], c["G"]
    iters = 10 if g == "G2" else 20

    qlen = inp["qlen_dev"].clone()
    kvlen = inp["kvlen_dev"].clone()
    sg = SinkGraph()
    sg.capture(inp["q"], inp["kpool"], inp["kpool"],
               query_rope=inp["qpe"], key_rope=inp["krpool"],
               atten_mask=inp["mask"] if c["use_mask"] else None,
               block_table=inp["bt"], actual_seq_qlen=qlen, actual_seq_kvlen=kvlen,
               num_query_heads=c["H"], num_key_value_heads=c["kvh"],
               input_layout=LAYOUT, sparse_mode=c["sparse_mode"], softmax_scale=inp["scale"],
               block_size=c["BS"], return_softmax_lse=True, warmup=2)
    torch.npu.synchronize()
    capture_ok = True

    res = dict(case=g, base_case=case_name, capture_ok=capture_ok, steps=[])

    if g == "G3":
        # qlen MTP-8 → MTP-7（[8,16,...,64]→[7,14,...,56]）+ 末 batch kvlen 置 0
        new_qlen = torch.tensor([G1_ * (i + 1) for i in range(B) for G1_ in [7]], dtype=torch.int64, device="npu")
        new_kv = kvlen.clone(); new_kv[-1] = 0
        qlen.copy_(new_qlen); kvlen.copy_(new_kv)
        out_g, lse_g = sg.replay(); torch.npu.synchronize()
        out_e, _ = eager_call(inp, qlen, kvlen); torch.npu.synchronize()
        # 有效 batch = 前 B-1 个请求的 token; 比较该区段（T 轴前 7*(B-1) 行）
        Tvalid = 7 * (B - 1)
        o_g = out_g[:, :Tvalid, :]; o_e = out_e[:, :Tvalid, :]
        cos = cos_of(o_g, o_e)
        bit_equal = torch.equal(o_g, o_e)
        max_abs = (o_g.float() - o_e.float()).abs().max().item()
        res["steps"].append(dict(step="qlen8to7_kv0last", cos_valid_region=cos,
                                 bit_equal_valid_region=bit_equal, max_abs=max_abs,
                                 shapes=[tuple(out_g.shape), tuple(out_e.shape)]))
        # 判定收紧为 bit 级（cos 对同分布输入不敏感, 会把固化误判为通过）
        res["passed"] = capture_ok and bit_equal
    else:
        # G1/G2: replay 24 步, 每步 kvlen += 8（原地）; 逐步与 eager 对齐
        kvs = []
        step_coses = []
        changed = False
        base_ref = None
        for step in range(24):
            if step > 0:
                kvlen.add_(8)
            out_g, _lse = sg.replay()
            torch.npu.synchronize()
            out_e, _ = eager_call(inp, qlen, kvlen, lse=False)
            torch.npu.synchronize()
            cos = cos_of(out_g, out_e)
            step_coses.append(cos)
            kvs.append(int(kvlen[0].item()))  # 仅记录用（host 读回只作证据, 不进算子路径）
            if base_ref is None:
                base_ref = out_g.clone()
            elif not torch.equal(base_ref, out_g):
                changed = True
        # 大幅 kvlen 变化（减半）验证输出非固化（+8/步的增量低于 BF16 分辨率, 不能作为变化证据）
        out_step24 = out_g.clone()   # 静态输出 buffer 会被下一次 replay 覆写, 先快照
        kvlen.mul_(0).add_(kvs[0] // 2)   # 大幅变化: 全部 kvlen 重设为首请求原值的一半
        out_big, _ = sg.replay()
        torch.npu.synchronize()
        out_e_big, _ = eager_call(inp, qlen, kvlen, lse=False)
        torch.npu.synchronize()
        cos_big = cos_of(out_big, out_e_big)
        big_changed = not torch.equal(out_step24, out_big)
        res["steps"] = [dict(n=24, cos_min=min(step_coses), cos_mean=sum(step_coses) / len(step_coses))]
        res["big_change_cos_vs_eager"] = cos_big
        res["output_changes_across_replay"] = bool(big_changed and cos_big >= 0.999)
        res["kv0_first_last"] = [kvs[0], kvs[-1]]
        res["passed"] = capture_ok and min(step_coses) >= 0.999 and res["output_changes_across_replay"]

    if g == "G2":
        # replay 性能 vs eager（sync 含执行: graph 在独立 stream 执行, 须用同步墙钟口径）
        # 事件+全程同步口径: s → (replay 执行) → sync → e, 保证窗口包含 graph 流执行
        def timed(fn, n):
            for _ in range(3):
                fn(); torch.npu.synchronize()
            ts = []
            for _ in range(n):
                sE = torch.npu.Event(enable_timing=True); eE = torch.npu.Event(enable_timing=True)
                sE.record()
                fn()
                torch.npu.synchronize()
                eE.record()
                torch.npu.synchronize()
                ts.append(sE.elapsed_time(eE) * 1e3)
            ts.sort()
            return ts[len(ts) // 2]
        replay_p50 = timed(lambda: sg.replay(), iters)
        eager_p50 = timed(lambda: eager_call(inp, qlen, kvlen, lse=False), iters)
        res["graph_replay_p50_us"] = replay_p50
        res["eager_p50_us"] = eager_p50
        res["ratio"] = replay_p50 / eager_p50
        res["passed"] = res["passed"] and res["ratio"] <= 1.05

    print(f"[{g}] {json.dumps({k: v for k, v in res.items() if k != 'steps'}, default=str)}")
    if json_out:
        os.makedirs(os.path.dirname(os.path.abspath(json_out)), exist_ok=True)
        json.dump(res, open(json_out, "w"), indent=1, default=str)
    return res["passed"]


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("cases", nargs="*")
    ap.add_argument("--json", default=None)
    a = ap.parse_args()
    names = a.cases or ["G1", "G2", "G3"]
    if len(names) == 1 and a.json:
        ok = run_case(names[0], a.json)
    else:
        ok = all([run_case(n) for n in names])
    sys.exit(0 if ok else 1)
