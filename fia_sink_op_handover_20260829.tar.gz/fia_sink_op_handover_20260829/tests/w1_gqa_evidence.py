"""W1 GQA 五层验证链 V1/V3 证据采集（plans/08 §3.2; 知识卡 aicpu-tiling-sink §5）。

V1 metadata 单测（GQA 形态）: 同 shape 不同 kvlen → meta usedCoreNum/s2Size 随 device 值变化;
  另证 rope_head_dim=0 确实路由进 AICPU GQA 分支（与 MLA 形态字段差异对照）。
V3 profiler 差分: 连续调用 sink 两段式 → FusedInferAttentionScoreV2SinkMetadata 每次 call
  在 device 执行 + D2H/H2D/aten::item == 0。
输出 JSON: r3_w1_v1v3_gqa.json
"""
import json, os, sys
import torch
import torch_npu
from torch_npu.profiler import profile, ProfilerActivity

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "python"))
from gqa_case_builder import resolve, parse_case, build_inputs, call_newop  # noqa: E402
from fia_v2_sink_entry import entry, metadata  # noqa: E402

BASE_OFF = 36 * 10 + 72 * 3


def run(out_json):
    c = parse_case(resolve("C21"))
    inp = build_inputs(c)

    # ---------- V1a: meta 关键字段随 kvlen（device 值）变化 ----------
    variants = []
    for delta in (0, 8, 64, 512, 4096):
        kv = inp["kvlen_dev"] + delta
        m = metadata(c["n1"], c["n2"], c["head_dim"], c["head_dim"], inp["qlen_dev"], kv,
                     sparse_mode=0, input_layout=c["input_layout"],
                     input_layout_kv="PA", rope_head_dim=0, block_size=c["block_size"])
        torch.npu.synchronize()
        mc = m.cpu()
        variants.append(dict(delta=delta,
                             usedCoreNum=int(mc[BASE_OFF + 4]),
                             s2Size=int(mc[BASE_OFF + 7]),
                             numOfFd=int(mc[BASE_OFF + 3]),
                             mBaseSize=int(mc[BASE_OFF + 0]),
                             sInnerSize=int(mc[BASE_OFF + 1])))
    v1_holds = len({v["usedCoreNum"] for v in variants}) > 1 or \
               len({v["s2Size"] for v in variants}) > 1 or \
               len({v["numOfFd"] for v in variants}) > 1

    # ---------- V1b: 与 MLA 形态（rope>0 且 D512+64+kv1）对照, 字段体现分支差异 ----------
    mla_meta = metadata(16, 1, 512, 512, inp["qlen_dev"], inp["kvlen_dev"],
                        sparse_mode=0, input_layout="TND_NTD", input_layout_kv="PA",
                        rope_head_dim=64, block_size=128)
    torch.npu.synchronize()
    mmc = mla_meta.cpu()
    mla_probe = dict(usedCoreNum=int(mmc[BASE_OFF + 4]), s2Size=int(mmc[BASE_OFF + 7]),
                     mBaseSize=int(mmc[BASE_OFF + 0]), sInnerSize=int(mmc[BASE_OFF + 1]))

    # ---------- V3: profiler 差分 ----------
    kw = dict(query_rope=None, key_rope=None,
              num_query_heads=c["n1"], num_key_value_heads=c["n2"],
              input_layout=c["input_layout"], input_layout_kv="PA",
              sparse_mode=c["sparse_mode"], softmax_scale=inp["scale"],
              block_table=inp["bt"], block_size=c["block_size"],
              actual_seq_qlen=inp["qlen_dev"], actual_seq_kvlen=inp["kvlen_dev"],
              return_softmax_lse=False)
    for _ in range(2):
        entry(inp["q"], inp["kpool"], inp["vpool"], **kw)
    torch.npu.synchronize()
    NCALL = 8
    with profile(activities=[ProfilerActivity.CPU, ProfilerActivity.NPU]) as prof:
        for _ in range(NCALL):
            entry(inp["q"], inp["kpool"], inp["vpool"], **kw)
        torch.npu.synchronize()

    os.makedirs("/tmp/fia_prof", exist_ok=True)
    prof.export_chrome_trace("/tmp/fia_prof/trace_gqa.json")
    raw = json.load(open("/tmp/fia_prof/trace_gqa.json"))
    tr = raw if isinstance(raw, list) else raw.get("traceEvents", [])
    evs = [e for e in tr if isinstance(e, dict) and e.get("ph") == "X"]

    def nm(e):
        return str(e.get("name", ""))

    meta_calls = [e for e in evs if "Metadata" in nm(e) and "FusedInferAttentionScoreV2Sink" in nm(e)]
    d2h = [e for e in evs if ("Memcpy" in nm(e) and ("DtoH" in nm(e) or "Device to Host" in nm(e)))
           or nm(e) == "aten::item"]
    h2d = [e for e in evs if "Memcpy" in nm(e) and ("HtoD" in nm(e) or "Host to Device" in nm(e))]

    r = dict(
        v1=dict(same_shape_kvlen_variants=variants,
                values_change_with_device_kvlen=v1_holds,
                mla_form_reference=mla_probe,
                gqa_vs_mla_field_diff=(variants[0]["mBaseSize"] != mla_probe["mBaseSize"])),
        v3=dict(meta_call_count=len(meta_calls), expected_calls=NCALL,
                aicpu_executed_per_call=len(meta_calls) >= NCALL,
                d2h_count=len(d2h), h2d_count=len(h2d),
                d2h_sample=[nm(e) for e in d2h[:3]], h2d_sample=[nm(e) for e in h2d[:3]],
                zero_d2h_h2d_item=(len(d2h) == 0 and len(h2d) == 0),
                trace="/tmp/fia_prof/trace_gqa.json"),
        case_form=dict(case="C21", layout=c["input_layout"], n1=c["n1"], n2=c["n2"],
                       head_dim=c["head_dim"], rope_head_dim=0),
    )
    r["v1_holds"] = r["v1"]["values_change_with_device_kvlen"]
    r["v3_holds"] = r["v3"]["aicpu_executed_per_call"] and r["v3"]["zero_d2h_h2d_item"]
    print(json.dumps(r, indent=1, ensure_ascii=False))
    if out_json:
        os.makedirs(os.path.dirname(os.path.abspath(out_json)) or ".", exist_ok=True)
        json.dump(r, open(out_json, "w"), indent=1)


if __name__ == "__main__":
    run(sys.argv[1] if len(sys.argv) > 1 else None)
