#!/bin/bash
# plans/05 全量门禁 runner: C01-C20 (精度+性能) + G1-G3 (图模式), 全部进程隔离。
# 用法: bash run_gate.sh <round_dir> [device_id] [phase]
#   phase = all | bench_base | bench_new | prec | graph
set -u
ROUND_DIR=${1:?round dir}
DEV=${2:-0}
PHASE=${3:-all}
HERE=$(cd "$(dirname "$0")" && pwd)
TESTS=$HERE
mkdir -p "$ROUND_DIR"
export ASCEND_RT_VISIBLE_DEVICES=$DEV
# 部署环境（plans/04 §3.2 双条目 ASCEND_CUSTOM_OPP_PATH）—— 新算子进程必需
source "$(cd "$HERE/.." && pwd)/deploy_env.sh" "$DEV" > /dev/null

PY=python3
CASES="C01 C02 C03 C04 C05 C06 C07 C08 C09 C10"
LONGCASES="C11 C12 C13 C14 C15 C16 C17 C18 C19 C20"
ALLCASES="C01 C02 C03 C04 C05 C06 C07 C08 C09 C10 C11 C12 C13 C14 C15 C16 C17 C18 C19 C20"

run_retry() {  # cmd... : 失败重试 <=3
  local n=0
  until "$@"; do
    n=$((n+1)); [ $n -ge 3 ] && return 1
    echo "[retry $n] $*"
    sleep 2
  done
}

if [ "$PHASE" = all ] || [ "$PHASE" = bench_base ]; then
  echo "== bench baseline (host list) =="
  for c in $CASES; do
    run_retry $PY "$TESTS/bench_sink.py" --cases "$c" --impl baseline --json "$ROUND_DIR/base_$c.json" || echo "BASE-$c FAILED" >> "$ROUND_DIR/failures.txt"
  done
  for c in $LONGCASES; do  # 长序列压测族: iters 10（plans/05 §5）
    run_retry $PY "$TESTS/bench_sink.py" --cases "$c" --impl baseline --iters 10 --json "$ROUND_DIR/base_$c.json" || echo "BASE-$c FAILED" >> "$ROUND_DIR/failures.txt"
  done
fi

if [ "$PHASE" = all ] || [ "$PHASE" = bench_new ]; then
  echo "== bench newop (device tensor) =="
  for c in $CASES; do
    run_retry $PY "$TESTS/bench_sink.py" --cases "$c" --impl newop --json "$ROUND_DIR/new_$c.json" || echo "NEW-$c FAILED" >> "$ROUND_DIR/failures.txt"
  done
  for c in $LONGCASES; do
    run_retry $PY "$TESTS/bench_sink.py" --cases "$c" --impl newop --iters 10 --json "$ROUND_DIR/new_$c.json" || echo "NEW-$c FAILED" >> "$ROUND_DIR/failures.txt"
  done
fi

if [ "$PHASE" = all ] || [ "$PHASE" = prec ]; then
  echo "== precision C01-C20 =="
  for c in $ALLCASES; do
    run_retry $PY "$TESTS/check_newop.py" "$c" --json "$ROUND_DIR/prec_$c.json" || echo "PREC-$c FAILED" >> "$ROUND_DIR/failures.txt"
  done
fi

if [ "$PHASE" = all ] || [ "$PHASE" = graph ]; then
  echo "== graph G1-G3 =="
  for g in G1 G2 G3; do
    run_retry $PY "$TESTS/graph_cases.py" "$g" --json "$ROUND_DIR/graph_$g.json" || echo "GRAPH-$g FAILED" >> "$ROUND_DIR/failures.txt"
  done
fi

echo "== gate done: $ROUND_DIR =="
ls "$ROUND_DIR" | wc -l
[ -f "$ROUND_DIR/failures.txt" ] && { echo "FAILURES:"; cat "$ROUND_DIR/failures.txt"; exit 1; } || echo "ALL RUNS COMPLETED"
