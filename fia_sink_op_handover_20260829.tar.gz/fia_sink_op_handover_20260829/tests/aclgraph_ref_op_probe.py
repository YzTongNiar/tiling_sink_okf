# 未修改 omni-ops 参考算子的 aclgraph 动态重放探针（TND 布局，规避参考实现的 TND_NTD F3 缺陷）
import torch, torch_npu
import omni_custom_ops  # noqa
import torch.nn.functional as F

DEV = "npu"
B, G, N1, N2 = 8, 8, 16, 1
D, DR, BS = 512, 64, 128
POOL = 1000
K1, K2 = 2560, 5120
BT_W = 40
scale = 0.0721687836487032

torch.manual_seed(7)
q = (torch.rand(B * G, N1, D, dtype=torch.bfloat16) * 2).to(DEV)
qr = (torch.rand(B * G, N1, DR, dtype=torch.bfloat16) * 2).to(DEV)
kc = (torch.rand(POOL, N2, BS, D, dtype=torch.bfloat16) * 2).to(DEV)
kr = (torch.rand(POOL, N2, BS, DR, dtype=torch.bfloat16) * 2).to(DEV)
perm = torch.randperm(POOL)
bt = perm[: B * BT_W].reshape(B, BT_W).to(torch.int32).to(DEV)
qlen = torch.tensor([G * (i + 1) for i in range(B)], dtype=torch.int64, device=DEV)
kvlen = torch.tensor([K1 + i for i in range(B)], dtype=torch.int64, device=DEV)  # 互异
K1v = kvlen.cpu().tolist()
K2v = [v + K2 - K1 for v in K1v]
p = torch.npu.get_device_properties(0)

def call(kv_dev, meta=None):
    m = meta
    if m is None:
        m = torch.ops.custom._npu_fused_infer_attention_sink_metadata(
            N1, N2, D, D, actual_seq_lengths=qlen, actual_seq_lengths_kv=kv_dev,
            batch_size=B, sparse_mode=0, pre_tokens=2147483647, next_tokens=2147483647,
            input_layout="TND", input_layout_kv="PA", sink_num=0, k_sink_num=0,
            rope_head_dim=DR, block_size=BS,
            aic_core_num=p.cube_core_num, aiv_core_num=p.vector_core_num)
    return torch.ops.custom.npu_fused_infer_attention_sink(
        q, kc, kc, query_rope=qr, key_rope=kr,
        actual_seq_qlen=qlen, actual_seq_kvlen=kv_dev, block_table=bt,
        num_query_heads=N1, num_key_value_heads=N2,
        input_layout="TND", sparse_mode=0, softmax_scale=scale,
        block_size=BS, meta_data=m, return_softmax_lse=True)[0]

def eager(kvs):
    kv = torch.tensor(kvs, dtype=torch.int64, device=DEV)
    o = call(kv); torch.npu.synchronize(); return o.clone()

ref1 = eager(K1v); ref2 = eager(K2v)
d_ref = (ref1.float() - ref2.float()).abs().max().item()
print(f"[sanity] eager(K1) vs eager(K2) max_abs={d_ref:.4f}", flush=True)
assert d_ref > 0.01

# 捕获（omni-ops 文档双流写法，补上 event.record）
s = torch.npu.Stream(); s.wait_stream(torch.npu.current_stream())
with torch.npu.stream(s):
    call(kvlen)  # warmup
torch.npu.current_stream().wait_stream(s)
torch.npu.synchronize()

g = torch.npu.NPUGraph()
aicore_stream = torch.npu.current_stream()
aicpu_stream = torch.npu.Stream()
event = torch.npu.Event()
out_g = None
with torch.npu.graph(g):
    with torch_npu.npu.stream(aicpu_stream):
        meta = torch.ops.custom._npu_fused_infer_attention_sink_metadata(
            N1, N2, D, D, actual_seq_lengths=qlen, actual_seq_lengths_kv=kvlen,
            batch_size=B, sparse_mode=0, pre_tokens=2147483647, next_tokens=2147483647,
            input_layout="TND", input_layout_kv="PA", sink_num=0, k_sink_num=0,
            rope_head_dim=DR, block_size=BS,
            aic_core_num=p.cube_core_num, aiv_core_num=p.vector_core_num)
        event.record(aicpu_stream)
    with torch_npu.npu.stream(aicore_stream):
        aicore_stream.wait_event(event)
        out_g = torch.ops.custom.npu_fused_infer_attention_sink(
            q, kc, kc, query_rope=qr, key_rope=kr,
            actual_seq_qlen=qlen, actual_seq_kvlen=kvlen, block_table=bt,
            num_query_heads=N1, num_key_value_heads=N2,
            input_layout="TND", sparse_mode=0, softmax_scale=scale,
            block_size=BS, meta_data=meta, return_softmax_lse=True)[0]
print("[capture] ok", flush=True)

def replay_out():
    g.replay(); torch.npu.synchronize()
    return out_g.clone()

o0 = replay_out()
print(f"[固定输入重放] vs eager(K1) max_abs={(o0.float()-ref1.float()).abs().max().item():.6f}", flush=True)

kvlen.copy_(torch.tensor(K2v, dtype=torch.int64, device=DEV))
o1 = replay_out()
d12 = (o1.float() - ref2.float()).abs().max().item()
d11 = (o1.float() - ref1.float()).abs().max().item()
print(f"[更新kvlen后重放] vs eager(K2)={d12:.6f} | vs eager(K1)={d11:.6f}", flush=True)
verdict = "DYNAMIC_OK" if d12 == 0 and d11 > 0.01 else ("FROZEN(参考算子同样固化)" if d11 == 0 else "MIXED")
print(f"[判定] {verdict}", flush=True)
print("REF_PROBE_DONE", flush=True)
