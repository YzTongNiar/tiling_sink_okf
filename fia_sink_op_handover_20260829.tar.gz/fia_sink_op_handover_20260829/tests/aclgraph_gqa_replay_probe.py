# W1 V5 探针：aclgraph 重放动态性（GQA 形态, gSize>1 且 rope=None）
# 口径与 aclgraph_decisive_replay_probe.py 完全一致, 仅替换输入形态:
#   N1=16,N2=8(gSize=2), head_dim=128, 无 rope 张量, sink 两段式走 AICPU GQA 分支。
# 判定一律 bit 级（R6, 禁 cos）:
#   固定输入重放 == eager(K1)?
#   kvlen 原地更新后重放 == eager(K2)? / == eager(K1)?   → DYNAMIC_OK / FROZEN / MIXED
#   K2 重捕获+重放 == eager(K2)?                          → 捕获用 live 值对照
import sys, torch, torch_npu

sys.path.insert(0, "/mnt/share/t00886357/cannbot/fia-tiling-sink/npu_fused_infer_attention_score_v2_sink/python")
from fia_v2_sink_entry import entry, SinkGraph

DEV = "npu"
B, G, N1, N2 = 8, 8, 16, 8          # gSize = 2（W1 GQA 形态）
D, BS = 128, 128
POOL = 1000
K1, K2 = 2560, 5120
BT_W = 40
scale = 128 ** -0.5

torch.manual_seed(7)
q = (torch.rand(B * G, N1, D, dtype=torch.bfloat16) * 2).to(DEV)
kpool = (torch.rand(POOL, N2, BS, D, dtype=torch.bfloat16) * 2).to(DEV)
vpool = (torch.rand(POOL, N2, BS, D, dtype=torch.bfloat16) * 2).to(DEV)
perm = torch.randperm(POOL)
bt = perm[: B * BT_W].reshape(B, BT_W).to(torch.int32).to(DEV)
qlen = torch.tensor([G * (i + 1) for i in range(B)], dtype=torch.int64, device=DEV)
kvlen = torch.tensor([K1] * B, dtype=torch.int64, device=DEV)
kvlen += torch.arange(B, device=DEV)      # 微扰保证 K1/K2 差异无歧义


def eager(kv_vals):
    kv = torch.tensor(kv_vals, dtype=torch.int64, device=DEV)
    o, _ = entry(q, kpool, vpool, query_rope=None, key_rope=None,
                 block_table=bt, actual_seq_qlen=qlen, actual_seq_kvlen=kv,
                 num_query_heads=N1, num_key_value_heads=N2,
                 input_layout="TND", input_layout_kv="PA",
                 sparse_mode=0, softmax_scale=scale, block_size=BS,
                 return_softmax_lse=True)
    torch.npu.synchronize()
    return o.clone()


def bits(a, b):
    return float((a.float() - b.float()).abs().max())


K1v = [K1 + i for i in range(B)]
K2v = [v + K2 - K1 for v in K1v]
ref1 = eager(K1v)
ref2 = eager(K2v)
d_ref = bits(ref1, ref2)
print(f"[sanity] eager(K1) vs eager(K2) max_abs={d_ref:.6f}", flush=True)
assert d_ref > 0.01

# 与官方算子的形态等价锚（进图前先证 sink==official on GQA@此形态, 已由门禁覆盖）

g = SinkGraph()
g.capture(q, kpool, vpool, query_rope=None, key_rope=None, atten_mask=None,
          block_table=bt, actual_seq_qlen=qlen, actual_seq_kvlen=kvlen,
          num_query_heads=N1, num_key_value_heads=N2,
          input_layout="TND", input_layout_kv="PA",
          sparse_mode=0, softmax_scale=scale, block_size=BS, return_softmax_lse=True)

o0 = g.replay()[0].clone()
torch.npu.synchronize()
print(f"[固定输入重放] vs eager(K1) max_abs={bits(o0, ref1):.6f}", flush=True)

kvlen.copy_(torch.tensor(K2v, dtype=torch.int64, device=DEV))
o1 = g.replay()[0].clone()
torch.npu.synchronize()
print(f"[更新kvlen后重放] vs eager(K2)={bits(o1, ref2):.6f} | vs eager(K1)={bits(o1, ref1):.6f}", flush=True)
verdict = ("DYNAMIC_OK(更新生效)" if bits(o1, ref2) == 0 and bits(o1, ref1) > 0.01
           else ("FROZEN(输出停在捕获值)" if bits(o1, ref1) == 0 else "MIXED"))
print(f"[判定] {verdict}", flush=True)

kvlen2 = torch.tensor(K2v, dtype=torch.int64, device=DEV)
g2 = SinkGraph()
g2.capture(q, kpool, vpool, query_rope=None, key_rope=None, atten_mask=None,
           block_table=bt, actual_seq_qlen=qlen, actual_seq_kvlen=kvlen2,
           num_query_heads=N1, num_key_value_heads=N2,
           input_layout="TND", input_layout_kv="PA",
           sparse_mode=0, softmax_scale=scale, block_size=BS, return_softmax_lse=True)
o2 = g2.replay()[0].clone()
torch.npu.synchronize()
print(f"[K2重捕获+重放] vs eager(K2) max_abs={bits(o2, ref2):.6f} "
      f"→ {'捕获用live值' if bits(o2, ref2) == 0 else '异常'}", flush=True)
print("EXP_DONE", flush=True)
