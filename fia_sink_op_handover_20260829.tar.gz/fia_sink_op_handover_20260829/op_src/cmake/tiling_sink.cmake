# Copyright (c) 2025 Huawei Technologies Co., Ltd. All rights reserved.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

set(FIA_SINK_SRC ${CMAKE_SOURCE_DIR}/src/ops-transformer/attention/fused_infer_attention_score_v2_sink/../common/op_host/fia_tiling_info.cpp
                 ${CMAKE_SOURCE_DIR}/src/ops-transformer/attention/fused_infer_attention_score_v2_sink/../common/op_host/fia_tiling_shape.cpp
                 ${CMAKE_SOURCE_DIR}/src/ops-transformer/attention/fused_infer_attention_score_v2_sink/../common/op_host/split_core.cpp
                 ${CMAKE_SOURCE_DIR}/src/ops-transformer/attention/fused_infer_attention_score_v2_sink/op_host/fused_infer_attention_score_v2_sink_tiling.cpp
                 ${CMAKE_SOURCE_DIR}/src/ops-transformer/attention/fused_infer_attention_score_v2_sink/op_host/fused_infer_attention_score_v2_sink_tiling_v3.cpp
                 ${CMAKE_SOURCE_DIR}/src/ops-transformer/attention/fused_infer_attention_score_v2_sink/op_host/fused_infer_attention_score_v2_sink_tiling_info_parser.cpp
                 ${CMAKE_SOURCE_DIR}/src/ops-transformer/attention/fused_infer_attention_score_v2_sink/op_host/fused_infer_attention_score_v2_sink_tiling_check.cpp
                 ${CMAKE_SOURCE_DIR}/src/ops-transformer/attention/fused_infer_attention_score_v2_sink/op_host/fused_infer_attention_score_v2_sink_tiling_check_single_para.cpp
                 ${CMAKE_SOURCE_DIR}/src/ops-transformer/attention/fused_infer_attention_score_v2_sink/op_host/fused_infer_attention_score_v2_sink_tiling_check_feature.cpp
                 ${CMAKE_SOURCE_DIR}/src/ops-transformer/attention/fused_infer_attention_score_v2_sink/op_host/fused_infer_attention_score_v2_sink_tiling_check_existence.cpp
                 ${CMAKE_SOURCE_DIR}/src/ops-transformer/attention/fused_infer_attention_score_v2_sink/op_host/fused_infer_attention_score_v2_sink_tiling_check_consistency.cpp
                 ${CMAKE_SOURCE_DIR}/src/ops-transformer/attention/fused_infer_attention_score_v2_sink/op_host/fia_tiling_nonquant_sink.cpp
                 ${CMAKE_SOURCE_DIR}/src/ops-transformer/attention/fused_infer_attention_score_v2_sink/op_host/fia_tiling_nonquant_mla_sink.cpp)

set(MERGED_SRC ${FIA_SINK_SRC})
ascendc_device_library(
    TARGET cust_opmaster
    OPTION SHARED
    SRC ${MERGED_SRC}
    INCLUDE_DIR ${CMAKE_SOURCE_DIR}/src/ops-transformer/attention)
