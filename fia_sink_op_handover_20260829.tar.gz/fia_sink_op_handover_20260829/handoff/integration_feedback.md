# integration_feedback —— D192 重建包整网复跑结果（第 1 轮）

> 2026-08-28　执行：接入 session（验证执行方）　纪律遵守：未修算子、未改框架/脚本

## 1. 功能验收：✅ 通过

| 项 | 结果 |
|---|---|
| 交接校验 | status=done；wheel/opp_run SHA256 双双匹配；OPP 双条目结构与旧包一致；schema_changed=false |
| 成对换装 | force-reinstall 新 wheel + ASCEND_CUSTOM_OPP_PATH→d192_delivery ✓ |
| 单算子 trust-but-verify（卡14） | **mqa_c27_g1_d192_tnd: bit_exact=True, max_abs=0.0**；mqa_c28_g1_d128_tnd: bit_exact=True |
| 整网启动 | graph capture 完成、health=200、fail-fast 注册通过、0 Traceback/ERROR |
| 历史崩溃 | `aclnnFusedInferAttentionScoreV2SinkV3 failed` 出现次数 = **0**（修复前 3/3 必现）→ **功能修复确认生效** |
| 请求（B=1, max_tokens=64, kvlen≈84 包络内） | 200，生成连贯，finish=length |

## 2. greedy 对拍主判据：⚠️ 无法据此判定 —— 发现服务栈跨实例非确定性（对照实验证据）

首分叉@57 字符（fia_on 与 baseline 的 64-token 输出文本不一致）。但归因前做了第三组对照，
**发现基线自身跨实例即不确定**：

| run | 开关 | 包 | 输出（分叉区） |
|---|---|---|---|
| baseline @ 08-27 | 0 | 旧包 | `**(注意力机制)**\n    *   **限制条件：** One sentence (一句话)` |
| baseline @ 08-28 | 0 | **新包** | `**(注意力机制)。**\n    * **限制条件：** Use exactly...` |
| fia_on @ 08-28 | 1 | 新包 | `**(注意力机制)**\n    *  **限制条件：** One sentence...` |

两个**同为开关 0、同官方路径**的基线在 ~57 字符同区域即互相分叉（且 08-28 的 fia_on 反而与
08-27 基线前缀更近）。结论：**本服务栈（TP8 + async-scheduling + DSpark 投机）跨实例非确定，
E2E 文本比对的噪声地板 > sink 引入的差异**，本轮对拍不能作为 sink 归因依据。

**假说（供算子侧参考，未验证）**：非确定性源 = 投机解码放大链——draft 由官方 v1 kernel 切到
sink（v2 族）后接受率变化（fia_on 均值接受长度 2.25）→ 每步 verify batch 形状变化 → target
logits 归约序抖动 → argmax 偶发翻转。C27/C28 已证 sink 与官方 v2 **bit 级一致**，数学主体无误。

## 3. 建议的受控实验（归因下轮，非本轮范围）

1. 同实例内 A/B：单实例先后发请求无法换开关 → 需两实例各发 N 次同 prompt，统计文本分布
   （基线自身分叉率 vs fia_on-vs-基线分叉率，卡方判定 sink 是否显著增加分叉）
2. 关 speculative（enforce_eager + 无 spec config）跑 target-only：sink 不在路径上，
   验证"开关 1 = 开关 0"退化一致性（隔离开关侧副作用）
3. `/v1/completions` + echo/logprobs 采集逐 token 分布，定位首分叉 token 的 logit 差量级
   （若 ~1e-3 内即归约序噪声；~1e-1 级才需怀疑数值路径）

## 4. 包络边界遵守记录（算子侧已登记，本轮实测未越界）

- B=1 单请求串行 ✓（未触发 D192 batch≥2 静默错值）
- 生成 ≤64 token，kvlen≈84 << 216 ✓（未触发 0x26）
- 未测越界复现（如需 0x26/0x2a 现场确认请另行立项）

## 5. 证据归档

- `logs/test_glm5_d192_on.log` / `logs/test_glm5_d192_baseline.log`（服务日志）
- `logs/d192_on_response.json` / `logs/d192_baseline_response.json`（完整响应）
- 08-27 基线输出（对照第三组）：本文件 §2 表内引文
- 环境版本：fia-sink-main @ `4da77e72d`（工作树干净）+ d192_delivery 包（SHA256 匹配）
