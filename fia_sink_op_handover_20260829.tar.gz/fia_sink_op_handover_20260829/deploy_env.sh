#!/bin/bash
# 部署环境引导（plans/04 §3.2 双条目 ASCEND_CUSTOM_OPP_PATH）
# source deploy_env.sh [device_id]
set -u
TASK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export ASCEND_RT_VISIBLE_DEVICES=${1:-0}

# 条目1（含 vendors/ 的根）: 供 CANN runtime 注册算子 + 加载 AICPU so
# 条目2（vendor 目录本身）: 供 torch 扩展按 <entry>/op_api/lib/libcust_opapi.so 解析 aclnn 符号
export ASCEND_CUSTOM_OPP_PATH="$TASK_DIR/install/custom/packages:$TASK_DIR/install/custom/packages/vendors/omni_custom_transformer"

echo "[deploy_env] ASCEND_RT_VISIBLE_DEVICES=$ASCEND_RT_VISIBLE_DEVICES"
echo "[deploy_env] ASCEND_CUSTOM_OPP_PATH=$ASCEND_CUSTOM_OPP_PATH"
