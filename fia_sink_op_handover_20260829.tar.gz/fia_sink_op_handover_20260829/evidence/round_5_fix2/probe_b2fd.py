import math, torch, sys
sys.path.insert(0, "/home/t00886357/npu_fused_infer_attention_score_v2_sink/tests")
sys.path.insert(0, "/home/t00886357/npu_fused_infer_attention_score_v2_sink/python")
from gqa_case_builder import bits_equal
import torch_npu
from fia_v2_sink_entry import entry
D, BS, qlen, kvlen = 192, 128, 7, 20
n2 = int(sys.argv[1])
scale = 1.0 / math.sqrt(D)
torch.manual_seed(33)
q = (torch.rand(2*qlen, n2, D)*2).bfloat16().npu()
pool = 4
kp = (torch.rand(pool, n2, BS, D)*2).bfloat16().npu()
vp = (torch.rand(pool, n2, BS, D)*2).bfloat16().npu()
bt = torch.tensor([[0],[1]], dtype=torch.int32).npu()
on, _ = entry(q, kp, vp, query_rope=None, key_rope=None, num_query_heads=n2,
              num_key_value_heads=n2, input_layout="TND", input_layout_kv="PA",
              sparse_mode=0, softmax_scale=scale, block_table=bt, block_size=BS,
              actual_seq_qlen=torch.tensor([7,7], dtype=torch.int64, device="npu"),
              actual_seq_kvlen=torch.tensor([20,20], dtype=torch.int64, device="npu"),
              return_softmax_lse=False)
srefs = []
for i in range(2):
    sn, _ = entry(q[i*7:(i+1)*7].contiguous(), kp, vp, query_rope=None, key_rope=None,
                  num_query_heads=n2, num_key_value_heads=n2, input_layout="TND", input_layout_kv="PA",
                  sparse_mode=0, softmax_scale=scale, block_table=bt[i:i+1].contiguous(), block_size=BS,
                  actual_seq_qlen=torch.tensor([7], dtype=torch.int64, device="npu"),
                  actual_seq_kvlen=torch.tensor([20], dtype=torch.int64, device="npu"),
                  return_softmax_lse=False)
    srefs.append(sn)
r0, m0, _ = bits_equal(on[:7].contiguous(), srefs[0])
r1, m1, _ = bits_equal(on[7:].contiguous(), srefs[1])
print(f"n2={n2} (tasks={2*n2}): req0_ok={r0} req1_ok={r1} mere1={m1}")
