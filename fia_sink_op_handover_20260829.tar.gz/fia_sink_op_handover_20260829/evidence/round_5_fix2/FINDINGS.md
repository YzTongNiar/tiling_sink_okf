# round_5（修复轮 2）结档 —— 2026-08-28

## #1 D192 kvlen 越界 0x26 —— ✅ 已修复
- 根因: GQA cube `fia_block_cube_nonquant_gqa_sink.h` ComputeMm2 的 K 分块写死 128。
  mm2 的 V→L0B 装载跨度 = kLoops×16×headDim, L0B 半区(128×128 el)按 D128 exact-fit 设计;
  D192 span=24,576 el (48KB) > 32KB 半区 ×1.5 → ping-pong buf0 越界静默污染 buf1(错值)/
  buf1 越界写穿 L0B(0x26)。奇偶依赖解释非单调边界(129 崩/145 活/208 活/209 崩)。
- 修复: K_SPLIT_SIZE/K_BASE 按 L0B 容量推导 min(128, (L0B_PP_SIZE/headDim)&~15)
  → D128=128(零变化), D192=80。仅 1 处头文件改动, D≤64/128 行为不变。
- 验证: kvlen {208,209,216,250,1024,4096,8192,32768} B=1 vs 官方 9.1 全部 bit_exact+lse bit 一致。

## #2 D192 B≥2 静默错值 —— ✅ 判定为【探针输入 bug, 非算子缺陷】
- 反转过程: on-device printf 插桩(FiaKernelNonQuant::GetTaskDealMode)抓到 bIdx=1 任务
  qLen=0 → gS1LoopTimes=0 → SKIP。追查 qActSeqLensParser(累计差分语义 GetValue(b)-GetValue(b-1))
  发现: 调试用探针把【逐请求 q-len [7,7]】当【累计 q-len】喂给 entry(TND 契约要求累计 [7,14])。
- 正确累计输入复验: B=2 kvlen {20,45,208,248} vs 官方 B=1 concat 全部 bit_exact=True;
  B=2 不等 qlen [7,5] bit_exact=True; B=4 混合批 bit_exact=True。
- 门禁族 C21–C26 之所以从未复现: case builder 一直用正确的累计 qlen_cum。

## #3 B≥2 不等 qlen metadata 0x2a —— ✅ 同为探针输入 bug
- 正确累计输入下 B=2 [7,5]、B=4 混合批均无 0x2a, bit 精确。#2/#3 撤销缺陷登记。

## 保留登记(非缺陷, 行为注记)
- D≥2 且 kvlen≥~4K: sink 的 FD 分块负载均衡与官方 B=1 不同 → fp32 归约序差,
  mere ~2e-05(远低于 bf16 分辨率 3.9e-3 与 P2 门限 7.8e-3), 非正确性问题;
  服务形态(kvlen≤数百)为 bit 级一致。

## 干净构建门禁(dev14, 无插桩): mqa_c27/c28 ✓, C21–C26 ✓(prec_*.json),
  B1 kvlen sweep ✓, B2 累计输入 ✓ —— 全绿, 交付 status=done。
