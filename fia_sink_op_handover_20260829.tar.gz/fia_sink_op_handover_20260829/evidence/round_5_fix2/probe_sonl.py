import math, torch, sys
sys.path.insert(0, "/home/t00886357/npu_fused_infer_attention_score_v2_sink/tests")
sys.path.insert(0, "/home/t00886357/npu_fused_infer_attention_score_v2_sink/python")
import torch_npu
from fia_v2_sink_entry import entry
D, n2 = 192, 8
kvlen, BS, qlen = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
scale = 1.0 / math.sqrt(D)
torch.manual_seed(3)
q = (torch.rand(qlen, n2, D)*2).bfloat16().npu()
pool = math.ceil(kvlen/BS) + 2
kp = (torch.rand(pool, n2, BS, D)*2).bfloat16().npu()
vp = (torch.rand(pool, n2, BS, D)*2).bfloat16().npu()
bt = torch.arange(pool, dtype=torch.int32).view(1, -1).npu()
on, _ = entry(q, kp, vp, query_rope=None, key_rope=None, num_query_heads=n2,
              num_key_value_heads=n2, input_layout="TND", input_layout_kv="PA",
              sparse_mode=0, softmax_scale=scale, block_table=bt, block_size=BS,
              actual_seq_qlen=torch.tensor([qlen], dtype=torch.int64, device="npu"),
              actual_seq_kvlen=torch.tensor([kvlen], dtype=torch.int64, device="npu"),
              return_softmax_lse=False)
torch.npu.synchronize()
print(f"SINK_OK kvlen={kvlen} BS={BS} qlen={qlen} finite={bool(torch.isfinite(on.float()).all().item())}")
