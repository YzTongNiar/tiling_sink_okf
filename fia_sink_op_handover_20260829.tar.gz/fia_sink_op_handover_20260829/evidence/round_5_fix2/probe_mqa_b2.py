import math, torch, sys
sys.path.insert(0, "/home/t00886357/npu_fused_infer_attention_score_v2_sink/tests")
sys.path.insert(0, "/home/t00886357/npu_fused_infer_attention_score_v2_sink/python")
from gqa_case_builder import bits_equal
import torch_npu
from fia_v2_sink_entry import entry
D, BS, qlen, kvlen = 192, 128, 7, 20
scale = 1.0 / math.sqrt(D)
torch.manual_seed(33)
q = (torch.rand(2*qlen, 1, D)*2).bfloat16().npu()
kp = (torch.rand(4, 1, BS, D)*2).bfloat16().npu()
vp = (torch.rand(4, 1, BS, D)*2).bfloat16().npu()
bt = torch.tensor([[0],[1]], dtype=torch.int32).npu()
on, _ = entry(q, kp, vp, query_rope=None, key_rope=None, num_query_heads=1,
              num_key_value_heads=1, input_layout="TND", input_layout_kv="PA",
              sparse_mode=0, softmax_scale=scale, block_table=bt, block_size=BS,
              actual_seq_qlen=torch.tensor([7,7], dtype=torch.int64, device="npu"),
              actual_seq_kvlen=torch.tensor([20,20], dtype=torch.int64, device="npu"),
              return_softmax_lse=False)
z = bool((on[7:].float() == 0).all().item())
print(f"MQA(n2=1) B=2: req1区全零={z}")
