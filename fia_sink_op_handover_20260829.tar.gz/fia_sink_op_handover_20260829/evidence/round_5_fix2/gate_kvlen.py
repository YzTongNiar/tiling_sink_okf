import math, torch, sys
sys.path.insert(0, "/home/t00886357/npu_fused_infer_attention_score_v2_sink/tests")
sys.path.insert(0, "/home/t00886357/npu_fused_infer_attention_score_v2_sink/python")
from gqa_case_builder import bits_equal
import torch_npu
from fia_v2_sink_entry import entry
D, BS, n2 = 192, 128, 8
kvlen, qlen, B = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
scale = 1.0 / math.sqrt(D)
torch.manual_seed(21)
ql = [qlen] * B
kl = [kvlen] * B
T = sum(ql)
q = (torch.rand(T, n2, D) * 2).bfloat16().npu()
nb = [math.ceil(x / BS) for x in kl]
pool = sum(nb) + 2
kp = (torch.rand(pool, n2, BS, D) * 2).bfloat16().npu()
vp = (torch.rand(pool, n2, BS, D) * 2).bfloat16().npu()
btw = max(nb)
bt = torch.zeros(B, btw, dtype=torch.int32)
st = 0
for i, n in enumerate(nb):
    bt[i, :n] = torch.arange(st, st + n); st += n
bt = bt.npu()
ob, lb = torch_npu.npu_fused_infer_attention_score_v2(
    q, kp, vp, num_query_heads=n2, num_key_value_heads=n2, input_layout="TND",
    sparse_mode=0, softmax_scale=scale, block_table=bt, block_size=BS,
    actual_seq_qlen=ql, actual_seq_kvlen=kl, return_softmax_lse=True)
on, ln = entry(q, kp, vp, query_rope=None, key_rope=None, num_query_heads=n2,
               num_key_value_heads=n2, input_layout="TND", input_layout_kv="PA",
               sparse_mode=0, softmax_scale=scale, block_table=bt, block_size=BS,
               actual_seq_qlen=torch.tensor(ql, dtype=torch.int64, device="npu"),
               actual_seq_kvlen=torch.tensor(kl, dtype=torch.int64, device="npu"),
               return_softmax_lse=True)
eq, m, mx = bits_equal(on, ob)
eql, _, _ = bits_equal(ln, lb)
print(f"GATE kvlen={kvlen} qlen={qlen} B={B}: bit_exact={eq} mere={m} lse_bit={eql}")
