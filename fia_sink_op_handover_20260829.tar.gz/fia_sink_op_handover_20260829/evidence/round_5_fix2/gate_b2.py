import math, torch, sys
sys.path.insert(0, "/home/t00886357/npu_fused_infer_attention_score_v2_sink/tests")
sys.path.insert(0, "/home/t00886357/npu_fused_infer_attention_score_v2_sink/python")
from gqa_case_builder import bits_equal
import torch_npu
from fia_v2_sink_entry import entry
D, BS, n2 = 192, 128, 8
kvlen, qlen = int(sys.argv[1]), int(sys.argv[2])
B, T = 2, 2 * qlen
scale = 1.0 / math.sqrt(D)
torch.manual_seed(33)
q = (torch.rand(T, n2, D) * 2).bfloat16().npu()
nb = math.ceil(kvlen / BS)
pool = nb * 2 + 2
kp = (torch.rand(pool, n2, BS, D) * 2).bfloat16().npu()
vp = (torch.rand(pool, n2, BS, D) * 2).bfloat16().npu()
bt = torch.zeros(2, nb, dtype=torch.int32)
bt[0, :] = torch.arange(nb)
bt[1, :] = torch.arange(nb, 2 * nb)
bt = bt.npu()
# 参照: 官方逐请求 B=1 (9.1 官方拒 D192 B>=2, error 561002)
refs = []
for i in range(B):
    ob, _ = torch_npu.npu_fused_infer_attention_score_v2(
        q[i*qlen:(i+1)*qlen].contiguous(), kp, vp, num_query_heads=n2, num_key_value_heads=n2,
        input_layout="TND", sparse_mode=0, softmax_scale=scale,
        block_table=bt[i:i+1].contiguous(), block_size=BS,
        actual_seq_qlen=[qlen], actual_seq_kvlen=[kvlen], return_softmax_lse=False)
    refs.append(ob)
ref = torch.cat(refs, 0)
on, _ = entry(q, kp, vp, query_rope=None, key_rope=None, num_query_heads=n2,
              num_key_value_heads=n2, input_layout="TND", input_layout_kv="PA",
              sparse_mode=0, softmax_scale=scale, block_table=bt, block_size=BS,
              actual_seq_qlen=torch.tensor([qlen, qlen], dtype=torch.int64, device="npu"),
              actual_seq_kvlen=torch.tensor([kvlen, kvlen], dtype=torch.int64, device="npu"),
              return_softmax_lse=False)
torch.npu.synchronize()
eq, m, _ = bits_equal(on, ref)
print(f"GATE_B2 kvlen={kvlen} qlen={qlen}: bit_exact_vs_official_concat={eq} mere={m}")
