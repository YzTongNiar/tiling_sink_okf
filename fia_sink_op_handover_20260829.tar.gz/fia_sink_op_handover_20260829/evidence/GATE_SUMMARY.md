# round_4 D192 重建 门禁与证据摘要（2026-08-28）

## 重建内容（遗留①闭环）
| 文件 | 改动 |
|---|---|
| `op_host/fused_infer_attention_score_v2_sink_tiling_v3.cpp` | `CheckGqaDSupport` 补 `(qk=192, rope=0, v=192)` 组合臂（GLM-5.2 DSpark draft qk=v=192 形态此前在 RouteToFia 即被拒） |
| `op_kernel/fused_infer_attention_score_v2_sink.cpp` | 按 103(HIGH_PERF) 族全矩阵镜像补 104(GENERAL_GQA) 族：PA 48 + NonPA 16 每 dtype（q∈{BNSD,BSH,TND,NTD} × kv∈{BNSD,BSH,NZ} × flags{2,3,6,7} / NonPA flags{0,1,4,5}），fp16 `half`、bf16 `bfloat16_t`，模板实参与 103 族逐字段一致 |

构建：F2 本地盘 `/tmp/fia_sink_build_d192`，9.1 链路（`build.sh -n "fused_infer_attention_score_v2_sink;fused_infer_attention_score_v2_sink_metadata" -c ascend910_93`）。
契约核验：op_api `libcust_opapi.so` 逐字节未变（schema 零变更）；`libcust_opmaster.so`/`libfia_v2_sink_aicpu_kernels.so` dynsym 与旧包一致；fatbin kernelList 112→176(fp16)/114→180(bf16)。

## 门禁结果（dev14, 9.1 + 新包双条目, 进程隔离）
| 门禁 | 结果 |
|---|---|
| C21–C26 全量回归 | 6/6 `bit_exact_vs_official=true, mere_vs_official=0.0, lse_bit_ok=true`（prec_C2*.json） |
| mqa_c27_g1_d192_tnd（核心验收） | `bit_exact=True mere_vs_base=0.0`（MERE_golden=0.174 为 P2 口径不作门禁） |
| mqa_c28_g1_d128_tnd（不得回归） | `bit_exact=True mere_vs_base=0.0` |
| 整网 3维 BBH 池探针（[pool,BS,N2*D], D192 g1 B1） | `bit_exact=True` + lse bit 一致（probe_bbh_d192.log） |

## 新边界（本轮实测登记, 详见 r3_w1_gqa_boundary.json update_round_4）
1. **D192 B=1 kvlen≥~216 → AICore 0x26（mte 写越界）**：208 OK / 216 崩；D128 同形态、9.1 官方同形态（kvlen 至 300）均正常 → 本仓 D192 GENERAL 模板自身问题（新遗留, 待定位）。
2. **D192 B≥2（等 q-len）→ 非首请求静默错值**（mere≈1.0；对照 sink/official B=1 逐请求输出均 bit 正确）→ D192 当前仅 B=1 形态 bit 可靠。
3. **B≥2 且各请求 qlen 不等（任意 D）→ metadata AICPU 0x2a 必现**：旧包同样复现 → 预先存在，与本轮重建无关；等 q-len（spec-decode 每步形态）B=2..4 已实测可跑通。

## 产物
- OPP .run：`/home/t00886357/fia_sink/handoff/d192_delivery/CANN-omni_custom_ops--linux.aarch64.run`（解压目录 `.../d192_delivery/opp/`）
- wheel：`.../d192_delivery/fia_v2_sink_ops-1.0-cp311-cp311-linux_aarch64.whl`（与 OPP 同一次构建）
- SHA256：`artifacts.sha256`；构建 CANN：9.1.0（V100R001C11SPC001B243）
- 回滚基线：`rollback/custom_prev_20260828/`（旧包全量 + sha256 清单）
